import React, { useState, useCallback, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card'
import { Button } from './components/ui/button'
import { Textarea } from './components/ui/textarea'
import { Input } from './components/ui/input'
import { Label } from './components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs'
import { Alert, AlertDescription } from './components/ui/alert'
import { Badge } from './components/ui/badge'
import { Progress } from './components/ui/progress'
import { Separator } from './components/ui/separator'
import { ScrollArea } from './components/ui/scroll-area'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import { AuthModal } from './components/AuthModal'
import { AnalysisHistory } from './components/AnalysisHistory'
import { ExportModal } from './components/ExportModal'
import { ModelInfoPanel } from './components/ModelInfoPanel'
import { ConfidenceWarning } from './components/ConfidenceWarning'
import { TextInput } from './components/TextInput'
import { api, SentimentAnalysis } from './utils/api'
import { 
  Brain, 
  Upload, 
  Download, 
  BarChart3, 
  TrendingUp, 
  FileText, 
  Zap, 
  Target, 
  AlertTriangle,
  User,
  LogOut,
  Save,
  RefreshCw,
  Eye,
  MessageSquare,
  ChevronDown,
  Plus,
  Minus,
  Heart,
  Frown,
  Meh,
  Smile,
  Angry,
  Star,
  Shield,
  ThumbsUp,
  Activity,
  BarChart
} from 'lucide-react'
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  BarChart as RechartsBarChart, 
  Bar, 
  Legend, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  AreaChart,
  Area,
  ComposedChart,
  ReferenceLine
} from 'recharts'

// Enhanced sentiment analysis function with emotional insights as supporting data
const analyzeSentiment = async (text: string): Promise<{
  sentiment: 'positive' | 'negative' | 'neutral'
  confidence: number
  scores: {
    positive: number
    negative: number
    neutral: number
  }
  emotions: {
    joy: number
    sadness: number
    anger: number
    fear: number
    surprise: number
    disgust: number
    trust: number
    anticipation: number
  }
  dominantEmotion: string
  emotionalIntensity: number
  keywords: string[]
}> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  // Sentiment and emotion keyword mapping
  const sentimentKeywords = {
    positive: ['good', 'great', 'excellent', 'amazing', 'love', 'fantastic', 'wonderful', 'awesome', 'happy', 'perfect', 'best', 'outstanding', 'brilliant', 'superb', 'delighted', 'pleased', 'satisfied', 'thrilled'],
    negative: ['bad', 'terrible', 'awful', 'hate', 'horrible', 'worst', 'sad', 'angry', 'disappointed', 'annoying', 'disgusting', 'revolting', 'frustrated', 'furious', 'miserable', 'appalling'],
    neutral: ['okay', 'fine', 'average', 'normal', 'standard', 'typical', 'regular', 'moderate', 'fair', 'decent']
  }

  const emotionKeywords = {
    joy: ['happy', 'joy', 'excited', 'cheerful', 'delighted', 'pleased', 'glad', 'thrilled', 'elated', 'wonderful', 'amazing', 'fantastic', 'excellent', 'perfect', 'love', 'adore'],
    sadness: ['sad', 'depressed', 'disappointed', 'unhappy', 'miserable', 'gloomy', 'melancholy', 'blue', 'down', 'heartbroken', 'grief', 'sorrow', 'despair', 'regret'],
    anger: ['angry', 'mad', 'furious', 'rage', 'irritated', 'annoyed', 'frustrated', 'outraged', 'livid', 'hate', 'disgusted', 'infuriated', 'resentful', 'hostile'],
    fear: ['afraid', 'scared', 'worried', 'anxious', 'nervous', 'terrified', 'frightened', 'panic', 'dread', 'concerned', 'apprehensive', 'uneasy', 'alarmed'],
    surprise: ['surprised', 'shocked', 'amazed', 'astonished', 'stunned', 'unexpected', 'incredible', 'unbelievable', 'wow', 'remarkable', 'extraordinary'],
    disgust: ['disgusting', 'revolting', 'repulsive', 'nauseating', 'gross', 'horrible', 'awful', 'terrible', 'sickening', 'appalling', 'vile'],
    trust: ['trust', 'reliable', 'confident', 'secure', 'faith', 'believe', 'dependable', 'credible', 'honest', 'loyal', 'authentic', 'genuine'],
    anticipation: ['excited', 'eager', 'hopeful', 'optimistic', 'looking forward', 'expect', 'anticipate', 'await', 'ready', 'prepared', 'enthusiastic']
  }
  
  const words = text.toLowerCase().split(/\s+/)
  
  // Calculate primary sentiment scores
  const sentimentScores = {
    positive: 0,
    negative: 0,
    neutral: 0
  }
  
  // Count sentiment words and calculate base scores
  Object.entries(sentimentKeywords).forEach(([sentiment, keywords]) => {
    const matches = words.filter(word => keywords.some(kw => word.includes(kw))).length
    sentimentScores[sentiment as keyof typeof sentimentScores] = Math.min(matches * 0.15 + Math.random() * 0.3, 0.9)
  })
  
  // Calculate emotion scores as supporting data
  const emotionScores = {
    joy: 0,
    sadness: 0,
    anger: 0,
    fear: 0,
    surprise: 0,
    disgust: 0,
    trust: 0,
    anticipation: 0
  }
  
  // Count emotion words and calculate base scores
  Object.entries(emotionKeywords).forEach(([emotion, keywords]) => {
    const matches = words.filter(word => keywords.some(kw => word.includes(kw))).length
    emotionScores[emotion as keyof typeof emotionScores] = Math.min(matches * 0.1 + Math.random() * 0.25, 0.8)
  })
  
  // Normalize sentiment scores
  const totalSentimentScore = Object.values(sentimentScores).reduce((sum, score) => sum + score, 0)
  if (totalSentimentScore > 0) {
    Object.keys(sentimentScores).forEach(sentiment => {
      sentimentScores[sentiment as keyof typeof sentimentScores] = 
        sentimentScores[sentiment as keyof typeof sentimentScores] / totalSentimentScore * 0.8 + Math.random() * 0.2
    })
  } else {
    // Default distribution if no keywords found
    sentimentScores.positive = Math.random() * 0.4 + 0.1
    sentimentScores.negative = Math.random() * 0.4 + 0.1
    sentimentScores.neutral = 1 - sentimentScores.positive - sentimentScores.negative
  }
  
  // Determine primary sentiment
  let sentiment: 'positive' | 'negative' | 'neutral'
  if (sentimentScores.positive > sentimentScores.negative && sentimentScores.positive > sentimentScores.neutral) {
    sentiment = 'positive'
  } else if (sentimentScores.negative > sentimentScores.neutral) {
    sentiment = 'negative'
  } else {
    sentiment = 'neutral'
  }
  
  // Calculate confidence as the highest sentiment score
  const confidence = Math.max(sentimentScores.positive, sentimentScores.negative, sentimentScores.neutral)
  
  // Normalize emotion scores
  const totalEmotionScore = Object.values(emotionScores).reduce((sum, score) => sum + score, 0)
  if (totalEmotionScore > 0) {
    Object.keys(emotionScores).forEach(emotion => {
      emotionScores[emotion as keyof typeof emotionScores] = 
        emotionScores[emotion as keyof typeof emotionScores] / totalEmotionScore * 0.6 + Math.random() * 0.3
    })
  } else {
    Object.keys(emotionScores).forEach(emotion => {
      emotionScores[emotion as keyof typeof emotionScores] = Math.random() * 0.3 + 0.1
    })
  }
  
  // Find dominant emotion for supporting insights
  const dominantEmotion = Object.entries(emotionScores).reduce((max, [emotion, score]) => 
    score > max.score ? { emotion, score } : max
  , { emotion: 'neutral', score: 0 }).emotion
  
  // Calculate emotional intensity
  const emotionalIntensity = Math.max(...Object.values(emotionScores))
  
  // Extract keywords that contributed to the analysis
  const foundKeywords = words.filter(word => 
    [...Object.values(sentimentKeywords), ...Object.values(emotionKeywords)].flat().some(kw => word.includes(kw))
  )
  
  return {
    sentiment,
    confidence,
    scores: sentimentScores,
    emotions: emotionScores,
    dominantEmotion,
    emotionalIntensity,
    keywords: foundKeywords.slice(0, 8)
  }
}

interface SentimentResult {
  text: string
  sentiment: 'positive' | 'negative' | 'neutral'
  confidence: number
  scores: {
    positive: number
    negative: number
    neutral: number
  }
  emotions: {
    joy: number
    sadness: number
    anger: number
    fear: number
    surprise: number
    disgust: number
    trust: number
    anticipation: number
  }
  dominantEmotion: string
  emotionalIntensity: number
  keywords: string[]
}

function SentimentAnalysisDashboard() {
  const { user, signOut, accessToken, isLoading: authLoading } = useAuth()
  const [singleText, setSingleText] = useState('')
  const [batchText, setBatchText] = useState('')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [results, setResults] = useState<SentimentResult[]>([])
  const [batchResults, setBatchResults] = useState<SentimentResult[]>([])
  const [activeTab, setActiveTab] = useState('single')
  const [comparisonTexts, setComparisonTexts] = useState(['', ''])
  const [comparisonResults, setComparisonResults] = useState<SentimentResult[]>([])
  const [isSaving, setIsSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState<string | null>(null)

  // Single text analysis
  const analyzeSingleText = async () => {
    if (!singleText.trim()) return
    
    setIsAnalyzing(true)
    try {
      const result = await analyzeSentiment(singleText)
      setResults([{ text: singleText, ...result }])
    } catch (error) {
      console.error('Analysis error:', error)
      alert('Analysis failed. Please try again.')
    } finally {
      setIsAnalyzing(false)
    }
  }

  // Batch text analysis
  const analyzeBatchText = async () => {
    if (!batchText.trim()) return
    
    const lines = batchText.split('\n').filter(line => line.trim())
    if (lines.length === 0) return
    
    setIsAnalyzing(true)
    try {
      const batchPromises = lines.map(async (line) => {
        const result = await analyzeSentiment(line.trim())
        return { text: line.trim(), ...result }
      })
      
      const batchAnalysisResults = await Promise.all(batchPromises)
      setBatchResults(batchAnalysisResults)
    } catch (error) {
      console.error('Batch analysis error:', error)
      alert('Batch analysis failed. Please try again.')
    } finally {
      setIsAnalyzing(false)
    }
  }

  // Comparison analysis
  const analyzeComparison = async () => {
    const validTexts = comparisonTexts.filter(text => text.trim())
    if (validTexts.length < 2) return
    
    setIsAnalyzing(true)
    try {
      const comparisonPromises = validTexts.map(async (text) => {
        const result = await analyzeSentiment(text.trim())
        return { text: text.trim(), ...result }
      })
      
      const comparisonAnalysisResults = await Promise.all(comparisonPromises)
      setComparisonResults(comparisonAnalysisResults)
    } catch (error) {
      console.error('Comparison analysis error:', error)
      alert('Comparison analysis failed. Please try again.')
    } finally {
      setIsAnalyzing(false)
    }
  }

  // Save analysis to backend
  const saveAnalysis = async (analysisData: Partial<SentimentAnalysis>) => {
    setIsSaving(true)
    setSaveMessage(null)
    
    try {
      const response = await api.saveAnalysis(analysisData, accessToken || undefined)
      setSaveMessage('Analysis saved successfully!')
      setTimeout(() => setSaveMessage(null), 3000)
    } catch (error) {
      console.error('Save analysis error:', error)
      setSaveMessage('Failed to save analysis')
      setTimeout(() => setSaveMessage(null), 3000)
    } finally {
      setIsSaving(false)
    }
  }

  const handleSaveSingleAnalysis = () => {
    if (results.length === 0) return
    
    const analysisData: Partial<SentimentAnalysis> = {
      text: singleText,
      results: results,
    }
    
    saveAnalysis(analysisData)
  }

  const handleSaveBatchAnalysis = () => {
    if (batchResults.length === 0) return
    
    const totalAnalyzed = batchResults.length
    const averageConfidence = batchResults.reduce((sum, result) => sum + result.confidence, 0) / totalAnalyzed
    const sentimentCounts = batchResults.reduce((counts, result) => {
      counts[result.sentiment]++
      return counts
    }, { positive: 0, negative: 0, neutral: 0 })
    
    const analysisData: Partial<SentimentAnalysis> = {
      batchResults: batchResults,
      summary: {
        totalAnalyzed,
        averageConfidence,
        sentimentDistribution: sentimentCounts
      }
    }
    
    saveAnalysis(analysisData)
  }

  // Load analysis from history
  const handleLoadAnalysis = (analysis: SentimentAnalysis) => {
    if (analysis.text && analysis.results) {
      setSingleText(analysis.text)
      setResults(analysis.results)
      setActiveTab('single')
    } else if (analysis.batchResults) {
      setBatchResults(analysis.batchResults)
      setActiveTab('batch')
    }
  }

  // Get export data for current tab
  const getExportData = () => {
    switch (activeTab) {
      case 'single':
        return { results, text: singleText }
      case 'batch':
        return { 
          batchResults,
          summary: batchResults.length > 0 ? {
            totalAnalyzed: batchResults.length,
            averageConfidence: batchResults.reduce((sum, result) => sum + result.confidence, 0) / batchResults.length,
            sentimentDistribution: batchResults.reduce((counts, result) => {
              counts[result.sentiment]++
              return counts
            }, { positive: 0, negative: 0, neutral: 0 })
          } : undefined
        }
      case 'comparison':
        return comparisonResults
      default:
        return []
    }
  }

  const getExportFilename = () => {
    switch (activeTab) {
      case 'single':
        return 'single-sentiment-analysis'
      case 'batch':
        return 'batch-sentiment-analysis'
      case 'comparison':
        return 'comparison-sentiment-analysis'
      default:
        return 'sentiment-analysis'
    }
  }

  // Visualization data functions
  const getSentimentChartData = (results: SentimentResult[]) => {
    if (results.length === 0) return []
    
    return results.map((result, index) => ({
      index: index + 1,
      text: result.text.slice(0, 15) + '...',
      positive: result.scores.positive,
      negative: result.scores.negative,
      neutral: result.scores.neutral,
      confidence: result.confidence,
      sentiment: result.sentiment
    }))
  }

  const getSentimentPieData = (results: SentimentResult[]) => {
    const counts = results.reduce((acc, result) => {
      acc[result.sentiment] = (acc[result.sentiment] || 0) + 1
      return acc
    }, {} as Record<string, number>)
    
    return Object.entries(counts).map(([sentiment, count]) => ({
      name: sentiment.charAt(0).toUpperCase() + sentiment.slice(1),
      value: count,
      percentage: ((count / results.length) * 100).toFixed(1)
    }))
  }

  const getEmotionSupportData = (result: SentimentResult) => {
    return Object.entries(result.emotions).map(([emotion, value]) => ({
      emotion: emotion.charAt(0).toUpperCase() + emotion.slice(1),
      value: value,
      fullMark: 1
    }))
  }

  const SENTIMENT_COLORS = {
    positive: '#10B981',
    negative: '#EF4444',
    neutral: '#6B7280'
  }

  const EMOTION_COLORS = {
    joy: '#FFD700',
    sadness: '#4682B4',
    anger: '#DC143C',
    fear: '#800080',
    surprise: '#FF8C00',
    disgust: '#8B4513',
    trust: '#228B22',
    anticipation: '#FF69B4'
  }

  const hasResults = () => {
    switch (activeTab) {
      case 'single':
        return results.length > 0
      case 'batch':
        return batchResults.length > 0
      case 'comparison':
        return comparisonResults.length > 0
      default:
        return false
    }
  }

  // Helper function to get sentiment badge variant
  const getSentimentBadgeVariant = (sentiment: string, confidence?: number) => {
    const baseVariant = sentiment === 'positive' ? 'default' :
                       sentiment === 'negative' ? 'destructive' : 'secondary'
    return baseVariant
  }

  // Helper function to get emotion icon
  const getEmotionIcon = (emotion: string) => {
    const icons = {
      joy: Smile,
      sadness: Frown,
      anger: Angry,
      fear: Shield,
      surprise: Star,
      disgust: Meh,
      trust: ThumbsUp,
      anticipation: Activity
    }
    return icons[emotion as keyof typeof icons] || Heart
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-600 rounded-lg">
              <BarChart className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl text-gray-900">Sentiment Analysis Dashboard</h1>
              <p className="text-gray-600">Analyze sentiment and emotional tone in text data with AI-powered insights</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-gray-600">
                  Welcome, {user.user_metadata?.name || user.email}
                </span>
                <Button variant="outline" onClick={signOut}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            ) : (
              <AuthModal>
                <Button variant="outline">
                  <User className="w-4 h-4 mr-2" />
                  Sign In / Sign Up
                </Button>
              </AuthModal>
            )}
          </div>
        </div>

        {/* Save Message */}
        {saveMessage && (
          <Alert className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{saveMessage}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Analysis Panel */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="w-5 h-5" />
                      Sentiment Text Analysis
                    </CardTitle>
                    <CardDescription>
                      Analyze sentiment patterns in text with comprehensive positive, negative, and neutral classification
                    </CardDescription>
                  </div>
                  
                  {/* Export Button */}
                  {hasResults() && (
                    <ExportModal
                      data={getExportData()}
                      defaultFilename={getExportFilename()}
                      title="Export Analysis Results"
                    >
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Export
                        <ChevronDown className="w-4 h-4 ml-2" />
                      </Button>
                    </ExportModal>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="single">Single Text</TabsTrigger>
                    <TabsTrigger value="batch">Batch Analysis</TabsTrigger>
                    <TabsTrigger value="comparison">Comparison</TabsTrigger>
                  </TabsList>

                  {/* Single Text Analysis */}
                  <TabsContent value="single" className="space-y-4">
                    <TextInput
                      value={singleText}
                      onChange={setSingleText}
                      label="Enter text to analyze"
                      placeholder="Type or paste your text here for sentiment analysis..."
                      description="Analyze sentiment patterns in a single piece of text"
                      acceptedFormats={['.txt']}
                      maxFileSize={5}
                    />
                    
                    <div className="flex gap-2">
                      <Button 
                        onClick={analyzeSingleText} 
                        disabled={!singleText.trim() || isAnalyzing}
                        className="flex-1"
                      >
                        {isAnalyzing ? (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Zap className="w-4 h-4 mr-2" />
                            Analyze Sentiment
                          </>
                        )}
                      </Button>
                      
                      {results.length > 0 && (
                        <Button
                          variant="outline"
                          onClick={handleSaveSingleAnalysis}
                          disabled={isSaving}
                        >
                          <Save className="w-4 h-4 mr-2" />
                          {isSaving ? 'Saving...' : 'Save'}
                        </Button>
                      )}
                    </div>

                    {/* Single Analysis Results */}
                    {results.length > 0 && (
                      <div className="space-y-6">
                        {results.map((result, index) => (
                          <div key={index} className="space-y-6">
                            {/* Main Sentiment Result Card */}
                            <Card>
                              <CardContent className="pt-6">
                                <div className="flex items-center justify-between mb-6">
                                  <div className="flex items-center gap-3">
                                    <Badge 
                                      variant={getSentimentBadgeVariant(result.sentiment, result.confidence)}
                                      className="text-lg px-3 py-1"
                                    >
                                      {result.sentiment.toUpperCase()}
                                    </Badge>
                                    <ConfidenceWarning 
                                      confidence={result.confidence} 
                                      variant="badge" 
                                    />
                                  </div>
                                  <div className="text-right">
                                    <p className="text-sm text-gray-600">Confidence Score</p>
                                    <p className="text-2xl font-medium">{Math.round(result.confidence * 100)}%</p>
                                  </div>
                                </div>
                                
                                <ConfidenceWarning confidence={result.confidence} />
                              </CardContent>
                            </Card>

                            {/* Primary Sentiment Visualizations */}
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                              {/* Sentiment Score Breakdown */}
                              <Card>
                                <CardHeader>
                                  <CardTitle className="text-lg">Sentiment Breakdown</CardTitle>
                                  <CardDescription>Detailed sentiment scores</CardDescription>
                                </CardHeader>
                                <CardContent>
                                  <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                                        <span className="font-medium">Positive</span>
                                      </div>
                                      <div className="flex items-center gap-2 flex-1 ml-4">
                                        <Progress value={result.scores.positive * 100} className="flex-1" />
                                        <span className="font-medium w-14">{Math.round(result.scores.positive * 100)}%</span>
                                      </div>
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                                        <span className="font-medium">Negative</span>
                                      </div>
                                      <div className="flex items-center gap-2 flex-1 ml-4">
                                        <Progress value={result.scores.negative * 100} className="flex-1" />
                                        <span className="font-medium w-14">{Math.round(result.scores.negative * 100)}%</span>
                                      </div>
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                                        <span className="font-medium">Neutral</span>
                                      </div>
                                      <div className="flex items-center gap-2 flex-1 ml-4">
                                        <Progress value={result.scores.neutral * 100} className="flex-1" />
                                        <span className="font-medium w-14">{Math.round(result.scores.neutral * 100)}%</span>
                                      </div>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>

                              {/* Sentiment Keywords */}
                              <Card>
                                <CardHeader>
                                  <CardTitle className="text-lg">Key Terms</CardTitle>
                                  <CardDescription>Words that influenced the sentiment</CardDescription>
                                </CardHeader>
                                <CardContent>
                                  {result.keywords.length > 0 ? (
                                    <div className="flex flex-wrap gap-2">
                                      {result.keywords.map((keyword, i) => (
                                        <Badge key={i} variant="outline" className="text-sm px-3 py-1">
                                          {keyword}
                                        </Badge>
                                      ))}
                                    </div>
                                  ) : (
                                    <p className="text-sm text-gray-500">No significant keywords detected</p>
                                  )}
                                </CardContent>
                              </Card>
                            </div>

                            {/* Supporting Emotional Insights */}
                            <Card>
                              <CardHeader>
                                <CardTitle className="text-lg flex items-center gap-2">
                                  <Heart className="w-5 h-5" />
                                  Emotional Context
                                  <Badge variant="secondary" className="text-xs">Supporting Insights</Badge>
                                </CardTitle>
                                <CardDescription>Additional emotional patterns detected in the text</CardDescription>
                              </CardHeader>
                              <CardContent>
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                  {/* Emotional Profile Radar */}
                                  <div>
                                    <ResponsiveContainer width="100%" height={200}>
                                      <RadarChart data={getEmotionSupportData(result)}>
                                        <PolarGrid />
                                        <PolarAngleAxis dataKey="emotion" className="text-xs" />
                                        <PolarRadiusAxis 
                                          angle={90} 
                                          domain={[0, 1]} 
                                          tickCount={4}
                                          className="text-xs"
                                        />
                                        <Radar
                                          name="Emotion Level"
                                          dataKey="value"
                                          stroke="#6366F1"
                                          fill="#6366F1"
                                          fillOpacity={0.2}
                                          strokeWidth={1}
                                        />
                                        <Tooltip 
                                          formatter={(value) => [`${Math.round(Number(value) * 100)}%`, 'Intensity']}
                                        />
                                      </RadarChart>
                                    </ResponsiveContainer>
                                  </div>

                                  {/* Dominant Emotion & Intensity */}
                                  <div className="space-y-4">
                                    <div>
                                      <p className="text-sm text-gray-600 mb-2">Dominant Emotion</p>
                                      <Badge variant="outline" className="flex items-center gap-2 w-fit">
                                        {React.createElement(getEmotionIcon(result.dominantEmotion), { className: "w-4 h-4" })}
                                        {result.dominantEmotion.charAt(0).toUpperCase() + result.dominantEmotion.slice(1)}
                                      </Badge>
                                    </div>
                                    <div>
                                      <p className="text-sm text-gray-600 mb-2">Emotional Intensity</p>
                                      <div className="flex items-center gap-2">
                                        <Progress value={result.emotionalIntensity * 100} className="flex-1" />
                                        <span className="text-sm font-medium">{Math.round(result.emotionalIntensity * 100)}%</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>

                  {/* Batch Analysis */}
                  <TabsContent value="batch" className="space-y-4">
                    <TextInput
                      value={batchText}
                      onChange={setBatchText}
                      label="Batch sentiment analysis"
                      placeholder="Enter multiple texts, one per line, or upload a file..."
                      description="Process multiple texts for comprehensive sentiment analysis"
                      supportsBatch={true}
                      acceptedFormats={['.txt', '.csv', '.json']}
                      maxFileSize={10}
                    />
                    
                    <div className="flex gap-2">
                      <Button 
                        onClick={analyzeBatchText} 
                        disabled={!batchText.trim() || isAnalyzing}
                        className="flex-1"
                      >
                        {isAnalyzing ? (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4 mr-2" />
                            Analyze Batch
                          </>
                        )}
                      </Button>
                      
                      {batchResults.length > 0 && (
                        <Button
                          variant="outline"
                          onClick={handleSaveBatchAnalysis}
                          disabled={isSaving}
                        >
                          <Save className="w-4 h-4 mr-2" />
                          {isSaving ? 'Saving...' : 'Save'}
                        </Button>
                      )}
                    </div>

                    {/* Batch Results */}
                    {batchResults.length > 0 && (
                      <div className="space-y-6">
                        {/* Low Confidence Warning */}
                        {batchResults.filter(r => r.confidence < 0.6).length > 0 && (
                          <Alert variant="destructive">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>
                              <strong>Low Confidence Alert:</strong> {batchResults.filter(r => r.confidence < 0.6).length} out of {batchResults.length} results have confidence below 60%.
                            </AlertDescription>
                          </Alert>
                        )}

                        {/* Summary Statistics */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Sentiment Analysis Summary</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                              <div className="text-center">
                                <p className="text-2xl font-medium">{batchResults.length}</p>
                                <p className="text-sm text-gray-600">Total Analyzed</p>
                              </div>
                              <div className="text-center">
                                <p className="text-2xl font-medium text-green-600">
                                  {batchResults.filter(r => r.sentiment === 'positive').length}
                                </p>
                                <p className="text-sm text-gray-600">Positive</p>
                              </div>
                              <div className="text-center">
                                <p className="text-2xl font-medium text-red-600">
                                  {batchResults.filter(r => r.sentiment === 'negative').length}
                                </p>
                                <p className="text-sm text-gray-600">Negative</p>
                              </div>
                              <div className="text-center">
                                <p className="text-2xl font-medium text-gray-600">
                                  {batchResults.filter(r => r.sentiment === 'neutral').length}
                                </p>
                                <p className="text-sm text-gray-600">Neutral</p>
                              </div>
                            </div>
                            
                            <Separator className="my-4" />
                            
                            <div className="text-center">
                              <p className="text-lg font-medium">
                                {Math.round(batchResults.reduce((sum, result) => sum + result.confidence, 0) / batchResults.length * 100)}%
                              </p>
                              <p className="text-sm text-gray-600">Average Confidence</p>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Primary Sentiment Visualizations */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          {/* Sentiment Distribution */}
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Sentiment Distribution</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ResponsiveContainer width="100%" height={250}>
                                <PieChart>
                                  <Pie
                                    data={getSentimentPieData(batchResults)}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={50}
                                    outerRadius={90}
                                    paddingAngle={5}
                                    dataKey="value"
                                  >
                                    <Cell fill={SENTIMENT_COLORS.positive} />
                                    <Cell fill={SENTIMENT_COLORS.negative} />
                                    <Cell fill={SENTIMENT_COLORS.neutral} />
                                  </Pie>
                                  <Tooltip formatter={(value) => [`${value} texts`]} />
                                  <Legend />
                                </PieChart>
                              </ResponsiveContainer>
                            </CardContent>
                          </Card>

                          {/* Confidence Distribution */}
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Confidence Levels</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ResponsiveContainer width="100%" height={250}>
                                <RechartsBarChart data={getSentimentChartData(batchResults).slice(0, 15)}>
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis dataKey="index" />
                                  <YAxis />
                                  <Tooltip formatter={(value) => [`${Math.round(Number(value) * 100)}%`]} />
                                  <Bar dataKey="confidence" fill="#6366F1" radius={[4, 4, 0, 0]} />
                                </RechartsBarChart>
                              </ResponsiveContainer>
                            </CardContent>
                          </Card>

                          {/* Sentiment Trend */}
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Sentiment Trend</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ResponsiveContainer width="100%" height={250}>
                                <LineChart data={getSentimentChartData(batchResults).slice(0, 20)}>
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis dataKey="index" />
                                  <YAxis />
                                  <Tooltip formatter={(value) => [`${Math.round(Number(value) * 100)}%`]} />
                                  <Line 
                                    type="monotone" 
                                    dataKey="positive" 
                                    stroke={SENTIMENT_COLORS.positive} 
                                    strokeWidth={2}
                                    name="Positive"
                                  />
                                  <Line 
                                    type="monotone" 
                                    dataKey="negative" 
                                    stroke={SENTIMENT_COLORS.negative} 
                                    strokeWidth={2}
                                    name="Negative"
                                  />
                                  <Line 
                                    type="monotone" 
                                    dataKey="neutral" 
                                    stroke={SENTIMENT_COLORS.neutral} 
                                    strokeWidth={2}
                                    name="Neutral"
                                  />
                                  <Legend />
                                </LineChart>
                              </ResponsiveContainer>
                            </CardContent>
                          </Card>

                          {/* Average Sentiment Scores */}
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Average Sentiment Scores</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ResponsiveContainer width="100%" height={250}>
                                <RechartsBarChart data={[
                                  {
                                    sentiment: 'Positive',
                                    score: batchResults.reduce((sum, r) => sum + r.scores.positive, 0) / batchResults.length
                                  },
                                  {
                                    sentiment: 'Negative', 
                                    score: batchResults.reduce((sum, r) => sum + r.scores.negative, 0) / batchResults.length
                                  },
                                  {
                                    sentiment: 'Neutral',
                                    score: batchResults.reduce((sum, r) => sum + r.scores.neutral, 0) / batchResults.length
                                  }
                                ]}>
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis dataKey="sentiment" />
                                  <YAxis />
                                  <Tooltip formatter={(value) => [`${Math.round(Number(value) * 100)}%`, 'Average Score']} />
                                  <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                                    <Cell fill={SENTIMENT_COLORS.positive} />
                                    <Cell fill={SENTIMENT_COLORS.negative} />
                                    <Cell fill={SENTIMENT_COLORS.neutral} />
                                  </Bar>
                                </RechartsBarChart>
                              </ResponsiveContainer>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Detailed Results Table */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Detailed Results</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ScrollArea className="h-64">
                              <div className="space-y-2">
                                {batchResults.map((result, index) => (
                                  <div key={index} className={`flex items-center justify-between p-3 rounded border ${
                                    result.confidence < 0.6 ? 'bg-red-50 border-red-200' : 'bg-gray-50 border-gray-200'
                                  }`}>
                                    <div className="flex-1">
                                      <p className="text-sm text-gray-700 truncate">{result.text}</p>
                                      {result.confidence < 0.6 && (
                                        <p className="text-xs text-red-600 mt-1">⚠️ Low confidence - review recommended</p>
                                      )}
                                    </div>
                                    <div className="flex items-center gap-2 ml-4">
                                      <Badge 
                                        variant={getSentimentBadgeVariant(result.sentiment, result.confidence)}
                                      >
                                        {result.sentiment}
                                      </Badge>
                                      <span className="text-xs text-gray-500">
                                        {Math.round(result.confidence * 100)}%
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </ScrollArea>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </TabsContent>

                  {/* Comparison Analysis */}
                  <TabsContent value="comparison" className="space-y-4">
                    <div className="space-y-4">
                      {comparisonTexts.map((text, index) => (
                        <div key={index}>
                          <TextInput
                            value={text}
                            onChange={(value) => {
                              const newTexts = [...comparisonTexts]
                              newTexts[index] = value
                              setComparisonTexts(newTexts)
                            }}
                            label={`Text ${index + 1}`}
                            placeholder={`Enter text ${index + 1} to compare sentiment...`}
                            acceptedFormats={['.txt']}
                            maxFileSize={5}
                          />
                        </div>
                      ))}
                      
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          onClick={() => setComparisonTexts([...comparisonTexts, ''])}
                          size="sm"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Text
                        </Button>
                        {comparisonTexts.length > 2 && (
                          <Button
                            variant="outline"
                            onClick={() => setComparisonTexts(comparisonTexts.slice(0, -1))}
                            size="sm"
                          >
                            <Minus className="w-4 h-4 mr-2" />
                            Remove Text
                          </Button>
                        )}
                      </div>
                    </div>
                    
                    <Button 
                      onClick={analyzeComparison} 
                      disabled={comparisonTexts.filter(t => t.trim()).length < 2 || isAnalyzing}
                      className="w-full"
                    >
                      {isAnalyzing ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Comparing...
                        </>
                      ) : (
                        <>
                          <Target className="w-4 h-4 mr-2" />
                          Compare Sentiment
                        </>
                      )}
                    </Button>

                    {/* Comparison Results */}
                    {comparisonResults.length > 0 && (
                      <div className="space-y-6">
                        {/* Low Confidence Warning */}
                        {comparisonResults.filter(r => r.confidence < 0.6).length > 0 && (
                          <Alert variant="destructive">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>
                              <strong>Low Confidence Alert:</strong> {comparisonResults.filter(r => r.confidence < 0.6).length} out of {comparisonResults.length} texts have low confidence scores.
                            </AlertDescription>
                          </Alert>
                        )}

                        {/* Sentiment Comparison Chart */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Sentiment Comparison</CardTitle>
                            <CardDescription>Compare sentiment patterns across texts</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <ResponsiveContainer width="100%" height={350}>
                              <RechartsBarChart 
                                data={['Positive', 'Negative', 'Neutral'].map(sentiment => {
                                  const dataPoint: any = { sentiment }
                                  comparisonResults.forEach((result, index) => {
                                    dataPoint[`Text ${index + 1}`] = result.scores[sentiment.toLowerCase() as keyof typeof result.scores]
                                  })
                                  return dataPoint
                                })}
                              >
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="sentiment" />
                                <YAxis />
                                <Tooltip formatter={(value) => [`${Math.round(Number(value) * 100)}%`]} />
                                <Legend />
                                {comparisonResults.map((_, index) => (
                                  <Bar 
                                    key={`bar-${index}`}
                                    dataKey={`Text ${index + 1}`} 
                                    fill={`hsl(${index * 120}, 70%, 50%)`}
                                  />
                                ))}
                              </RechartsBarChart>
                            </ResponsiveContainer>
                          </CardContent>
                        </Card>

                        {/* Individual Comparison Results */}
                        <div className="grid gap-4">
                          {comparisonResults.map((result, index) => (
                            <Card key={index}>
                              <CardHeader className="pb-3">
                                <div className="flex items-start justify-between">
                                  <CardTitle className="text-base">Text {index + 1}</CardTitle>
                                  <div className="flex items-center gap-2">
                                    <Badge 
                                      variant={getSentimentBadgeVariant(result.sentiment, result.confidence)}
                                      className="text-sm"
                                    >
                                      {result.sentiment} ({Math.round(result.confidence * 100)}%)
                                    </Badge>
                                  </div>
                                </div>
                              </CardHeader>
                              <CardContent>
                                <p className="text-sm text-gray-700 mb-4">{result.text}</p>
                                
                                <ConfidenceWarning confidence={result.confidence} />
                                
                                <div className="mt-4">
                                  <h4 className="text-sm font-medium mb-3">Sentiment Breakdown</h4>
                                  <div className="grid grid-cols-3 gap-2 text-sm">
                                    <div className="text-center p-3 bg-green-50 rounded">
                                      <p className="font-medium text-green-600 text-lg">{Math.round(result.scores.positive * 100)}%</p>
                                      <p className="text-gray-600">Positive</p>
                                    </div>
                                    <div className="text-center p-3 bg-red-50 rounded">
                                      <p className="font-medium text-red-600 text-lg">{Math.round(result.scores.negative * 100)}%</p>
                                      <p className="text-gray-600">Negative</p>
                                    </div>
                                    <div className="text-center p-3 bg-gray-50 rounded">
                                      <p className="font-medium text-gray-600 text-lg">{Math.round(result.scores.neutral * 100)}%</p>
                                      <p className="text-gray-600">Neutral</p>
                                    </div>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Analysis History Sidebar */}
          <div className="lg:col-span-1">
            <AnalysisHistory onLoadAnalysis={handleLoadAnalysis} />
          </div>
        </div>

        {/* Enhanced Model Information Panel */}
        <ModelInfoPanel />
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <SentimentAnalysisDashboard />
    </AuthProvider>
  )
}