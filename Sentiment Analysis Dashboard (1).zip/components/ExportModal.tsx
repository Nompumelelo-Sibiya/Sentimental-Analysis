import React, { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Checkbox } from './ui/checkbox'
import { Alert, AlertDescription } from './ui/alert'
import { Progress } from './ui/progress'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { api, ExportFormat, ExportOptions } from '../utils/api'
import { 
  Download, 
  FileJson, 
  FileSpreadsheet, 
  FileText,
  AlertCircle,
  CheckCircle,
  Loader2,
  BarChart3,
  Wifi,
  WifiOff
} from 'lucide-react'

interface ExportModalProps {
  data: any
  analysisId?: string
  defaultFilename?: string
  children: React.ReactNode
  title?: string
}

export function ExportModal({ 
  data, 
  analysisId, 
  defaultFilename = 'sentiment-analysis', 
  children, 
  title = 'Export Analysis' 
}: ExportModalProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedFormat, setSelectedFormat] = useState<ExportFormat>('json')
  const [filename, setFilename] = useState(defaultFilename)
  const [includeCharts, setIncludeCharts] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const [exportProgress, setExportProgress] = useState(0)
  const [exportStatus, setExportStatus] = useState<{
    type: 'success' | 'error' | 'warning' | null
    message: string
  }>({ type: null, message: '' })

  const formatOptions = [
    {
      value: 'json' as ExportFormat,
      label: 'JSON',
      description: 'Raw data in JSON format',
      icon: FileJson,
      color: 'text-blue-600'
    },
    {
      value: 'csv' as ExportFormat,
      label: 'CSV',
      description: 'Spreadsheet compatible format',
      icon: FileSpreadsheet,
      color: 'text-green-600'
    },
    {
      value: 'pdf' as ExportFormat,
      label: 'PDF',
      description: 'Professional report document',
      icon: FileText,
      color: 'text-red-600'
    }
  ]

  const handleExport = async () => {
    if (!filename.trim()) {
      setExportStatus({
        type: 'error',
        message: 'Please enter a filename'
      })
      return
    }

    setIsExporting(true)
    setExportProgress(0)
    setExportStatus({ type: null, message: '' })

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setExportProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + Math.random() * 20
        })
      }, 200)

      const exportOptions: ExportOptions = {
        format: selectedFormat,
        includeCharts,
        filename: filename.trim()
      }

      let success = false
      let usedFallback = false
      
      try {
        // Try backend export first
        let response
        if (analysisId) {
          response = await api.exportAnalysis(analysisId, exportOptions)
        } else {
          response = await api.exportData(data, exportOptions)
        }

        if (response.success) {
          // Backend export successful
          const link = document.createElement('a')
          link.href = response.downloadUrl
          link.download = response.fileName
          document.body.appendChild(link)
          link.click()
          document.body.removeChild(link)
          success = true
        }
      } catch (backendError) {
        console.warn('Backend export failed, using client-side fallback:', backendError)
        
        // Use client-side fallback
        try {
          const fallbackResponse = await api.exportDataClientSide(data, exportOptions)
          if (fallbackResponse.success) {
            success = true
            usedFallback = true
            setExportStatus({
              type: 'warning',
              message: fallbackResponse.message
            })
          }
        } catch (fallbackError) {
          throw fallbackError
        }
      }

      clearInterval(progressInterval)
      setExportProgress(100)

      if (success && !usedFallback) {
        setExportStatus({
          type: 'success',
          message: `Successfully exported as ${selectedFormat.toUpperCase()}`
        })
      }

      if (success) {
        // Close modal after successful export
        setTimeout(() => {
          setIsOpen(false)
          setExportStatus({ type: null, message: '' })
          setExportProgress(0)
        }, 3000)
      } else {
        throw new Error('Export failed')
      }
    } catch (error) {
      setExportProgress(0)
      const errorMessage = error instanceof Error ? error.message : 'Export failed'
      console.error('Export error:', errorMessage)
      setExportStatus({
        type: 'error',
        message: errorMessage
      })
    } finally {
      setIsExporting(false)
    }
  }

  const getFileExtension = (format: ExportFormat) => {
    switch (format) {
      case 'json': return '.json'
      case 'csv': return '.csv'
      case 'pdf': return '.pdf'
      default: return ''
    }
  }

  const getDataPreview = () => {
    const results = data?.results || data?.batchResults || (Array.isArray(data) ? data : [])
    const count = results.length || 0
    
    if (count === 0) {
      return 'No data to export'
    }
    
    return `${count} analysis result${count !== 1 ? 's' : ''}`
  }

  const selectedFormatOption = formatOptions.find(opt => opt.value === selectedFormat)

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]" aria-describedby="export-modal-description">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            {title}
          </DialogTitle>
          <DialogDescription id="export-modal-description">
            Export your sentiment analysis results in multiple formats. Choose from JSON for raw data, 
            CSV for spreadsheet compatibility, or PDF for professional reports.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Export Mode Info */}
          <Alert>
            <Wifi className="h-4 w-4" />
            <AlertDescription>
              <strong>Export Mode:</strong> Attempting backend export first, with client-side fallback if unavailable.
            </AlertDescription>
          </Alert>

          {/* Data Preview */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Export Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">{getDataPreview()}</p>
            </CardContent>
          </Card>

          {/* Format Selection */}
          <div className="space-y-3">
            <Label>Export Format</Label>
            <div className="grid gap-3">
              {formatOptions.map((option) => {
                const IconComponent = option.icon
                return (
                  <div
                    key={option.value}
                    className={`p-3 border rounded-lg cursor-pointer transition-all ${
                      selectedFormat === option.value 
                        ? 'border-primary bg-primary/5' 
                        : 'border-border hover:border-primary/50'
                    }`}
                    onClick={() => setSelectedFormat(option.value)}
                  >
                    <div className="flex items-center gap-3">
                      <IconComponent className={`w-5 h-5 ${option.color}`} />
                      <div className="flex-1">
                        <p className="font-medium">{option.label}</p>
                        <p className="text-sm text-gray-600">{option.description}</p>
                      </div>
                      <div className={`w-4 h-4 border-2 rounded-full ${
                        selectedFormat === option.value 
                          ? 'border-primary bg-primary' 
                          : 'border-gray-300'
                      }`}>
                        {selectedFormat === option.value && (
                          <div className="w-full h-full rounded-full bg-white scale-50" />
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Filename Input */}
          <div className="space-y-2">
            <Label htmlFor="filename">Filename</Label>
            <div className="flex">
              <Input
                id="filename"
                value={filename}
                onChange={(e) => setFilename(e.target.value)}
                placeholder="Enter filename"
                className="rounded-r-none"
              />
              <div className="px-3 py-2 bg-gray-100 border border-l-0 rounded-r-md text-sm text-gray-600">
                {getFileExtension(selectedFormat)}
              </div>
            </div>
          </div>

          {/* Options */}
          {selectedFormat === 'pdf' && (
            <div className="space-y-3">
              <Label>PDF Options</Label>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-charts"
                  checked={includeCharts}
                  onCheckedChange={setIncludeCharts}
                />
                <Label 
                  htmlFor="include-charts" 
                  className="text-sm flex items-center gap-2"
                >
                  <BarChart3 className="w-4 h-4" />
                  Include visualizations and charts
                </Label>
              </div>
              <Alert>
                <WifiOff className="h-4 w-4" />
                <AlertDescription>
                  PDF export requires backend processing. If unavailable, data will be exported as JSON format.
                </AlertDescription>
              </Alert>
            </div>
          )}

          {/* Export Progress */}
          {isExporting && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Generating {selectedFormatOption?.label} export...</span>
                <span>{Math.round(exportProgress)}%</span>
              </div>
              <Progress value={exportProgress} />
            </div>
          )}

          {/* Status Messages */}
          {exportStatus.type && (
            <Alert variant={exportStatus.type === 'error' ? 'destructive' : 'default'}>
              {exportStatus.type === 'success' ? (
                <CheckCircle className="h-4 w-4" />
              ) : exportStatus.type === 'warning' ? (
                <AlertCircle className="h-4 w-4" />
              ) : (
                <AlertCircle className="h-4 w-4" />
              )}
              <AlertDescription>{exportStatus.message}</AlertDescription>
            </Alert>
          )}

          {/* Export Button */}
          <div className="flex gap-3 pt-4">
            <Button 
              variant="outline" 
              onClick={() => setIsOpen(false)}
              disabled={isExporting}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleExport} 
              disabled={isExporting || !filename.trim()}
              className="flex-1"
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Export {selectedFormatOption?.label}
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}