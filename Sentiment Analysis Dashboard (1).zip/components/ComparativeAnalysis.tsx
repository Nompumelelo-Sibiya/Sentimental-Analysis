import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { ExportResults } from './ExportResults';
import { Download, TrendingUp, TrendingDown, Minus } from 'lucide-react';

export function ComparativeAnalysis({ analysisHistory }) {
  const [timeRange, setTimeRange] = useState('all');
  const [groupBy, setGroupBy] = useState('hour');

  const filteredHistory = useMemo(() => {
    if (!analysisHistory.length) return [];
    
    const now = new Date();
    const cutoff = new Date();
    
    switch (timeRange) {
      case 'day':
        cutoff.setDate(now.getDate() - 1);
        break;
      case 'week':
        cutoff.setDate(now.getDate() - 7);
        break;
      case 'month':
        cutoff.setMonth(now.getMonth() - 1);
        break;
      default:
        cutoff.setFullYear(2000); // Include all
    }
    
    return analysisHistory.filter(item => new Date(item.timestamp) >= cutoff);
  }, [analysisHistory, timeRange]);

  const trendData = useMemo(() => {
    if (!filteredHistory.length) return [];
    
    const grouped = {};
    
    filteredHistory.forEach(item => {
      const date = new Date(item.timestamp);
      let key;
      
      switch (groupBy) {
        case 'hour':
          key = `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:00`;
          break;
        case 'day':
          key = `${date.getMonth() + 1}/${date.getDate()}`;
          break;
        case 'week':
          const weekStart = new Date(date);
          weekStart.setDate(date.getDate() - date.getDay());
          key = `Week of ${weekStart.getMonth() + 1}/${weekStart.getDate()}`;
          break;
        default:
          key = `${date.getMonth() + 1}/${date.getDate()}`;
      }
      
      if (!grouped[key]) {
        grouped[key] = {
          time: key,
          positive: 0,
          negative: 0,
          neutral: 0,
          count: 0,
          avgConfidence: 0
        };
      }
      
      grouped[key][item.overall_sentiment]++;
      grouped[key].count++;
      grouped[key].avgConfidence += item.confidence;
    });
    
    return Object.values(grouped).map(group => ({
      ...group,
      avgConfidence: (group.avgConfidence / group.count) * 100,
      positivePercent: (group.positive / group.count) * 100,
      negativePercent: (group.negative / group.count) * 100,
      neutralPercent: (group.neutral / group.count) * 100
    })).sort((a, b) => a.time.localeCompare(b.time));
  }, [filteredHistory, groupBy]);

  const overallStats = useMemo(() => {
    if (!filteredHistory.length) return null;
    
    const total = filteredHistory.length;
    const positive = filteredHistory.filter(item => item.overall_sentiment === 'positive').length;
    const negative = filteredHistory.filter(item => item.overall_sentiment === 'negative').length;
    const neutral = filteredHistory.filter(item => item.overall_sentiment === 'neutral').length;
    const avgConfidence = filteredHistory.reduce((sum, item) => sum + item.confidence, 0) / total;
    
    // Calculate trend (compare first half vs second half)
    const midpoint = Math.floor(total / 2);
    const firstHalf = filteredHistory.slice(0, midpoint);
    const secondHalf = filteredHistory.slice(midpoint);
    
    const firstHalfPositive = firstHalf.filter(item => item.overall_sentiment === 'positive').length / firstHalf.length;
    const secondHalfPositive = secondHalf.filter(item => item.overall_sentiment === 'positive').length / secondHalf.length;
    
    const trend = secondHalfPositive - firstHalfPositive;
    
    return {
      total,
      positive,
      negative,
      neutral,
      avgConfidence,
      trend,
      positivePercent: (positive / total) * 100,
      negativePercent: (negative / total) * 100,
      neutralPercent: (neutral / total) * 100
    };
  }, [filteredHistory]);

  const sentimentDistribution = useMemo(() => {
    if (!overallStats) return [];
    
    return [
      { name: 'Positive', value: overallStats.positive, color: '#22c55e', percent: overallStats.positivePercent },
      { name: 'Negative', value: overallStats.negative, color: '#ef4444', percent: overallStats.negativePercent },
      { name: 'Neutral', value: overallStats.neutral, color: '#6b7280', percent: overallStats.neutralPercent }
    ];
  }, [overallStats]);

  const keywordAnalysis = useMemo(() => {
    if (!filteredHistory.length) return {};
    
    const keywordCounts = {};
    
    filteredHistory.forEach(item => {
      if (item.keywords) {
        item.keywords.forEach(keyword => {
          if (!keywordCounts[keyword.word]) {
            keywordCounts[keyword.word] = {
              word: keyword.word,
              positive: 0,
              negative: 0,
              neutral: 0,
              total: 0
            };
          }
          keywordCounts[keyword.word][keyword.sentiment]++;
          keywordCounts[keyword.word].total++;
        });
      }
    });
    
    return Object.values(keywordCounts)
      .filter(keyword => keyword.total >= 2)
      .sort((a, b) => b.total - a.total)
      .slice(0, 10);
  }, [filteredHistory]);

  const getTrendIcon = (trend) => {
    if (trend > 0.1) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (trend < -0.1) return <TrendingDown className="h-4 w-4 text-red-600" />;
    return <Minus className="h-4 w-4 text-gray-600" />;
  };

  const getTrendText = (trend) => {
    if (trend > 0.1) return `+${(trend * 100).toFixed(1)}% more positive`;
    if (trend < -0.1) return `${(trend * 100).toFixed(1)}% less positive`;
    return 'No significant trend';
  };

  if (!analysisHistory.length) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground">No analysis data available yet. Run some sentiment analyses to see comparative insights.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex gap-4">
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Time</SelectItem>
            <SelectItem value="month">Last Month</SelectItem>
            <SelectItem value="week">Last Week</SelectItem>
            <SelectItem value="day">Last Day</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={groupBy} onValueChange={setGroupBy}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="hour">By Hour</SelectItem>
            <SelectItem value="day">By Day</SelectItem>
            <SelectItem value="week">By Week</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {overallStats && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Total Analyses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">{overallStats.total}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Avg Confidence</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">{(overallStats.avgConfidence * 100).toFixed(1)}%</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Sentiment Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                {getTrendIcon(overallStats.trend)}
                <span className="text-sm">{getTrendText(overallStats.trend)}</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Top Sentiment</CardTitle>
            </CardHeader>
            <CardContent>
              <Badge variant={
                overallStats.positive >= overallStats.negative && overallStats.positive >= overallStats.neutral ? 'default' :
                overallStats.negative >= overallStats.neutral ? 'destructive' : 'secondary'
              }>
                {overallStats.positive >= overallStats.negative && overallStats.positive >= overallStats.neutral ? 'Positive' :
                 overallStats.negative >= overallStats.neutral ? 'Negative' : 'Neutral'}
              </Badge>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Sentiment Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="positivePercent" stroke="#22c55e" name="Positive %" />
                <Line type="monotone" dataKey="negativePercent" stroke="#ef4444" name="Negative %" />
                <Line type="monotone" dataKey="neutralPercent" stroke="#6b7280" name="Neutral %" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Overall Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={sentimentDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${percent.toFixed(1)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {sentimentDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Top Keywords Across Analyses</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={keywordAnalysis}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="word" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="positive" stackId="a" fill="#22c55e" name="Positive" />
              <Bar dataKey="neutral" stackId="a" fill="#6b7280" name="Neutral" />
              <Bar dataKey="negative" stackId="a" fill="#ef4444" name="Negative" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Export Comparative Report</CardTitle>
            <ExportResults 
              data={{
                analysis_type: 'comparative',
                time_range: timeRange,
                group_by: groupBy,
                statistics: overallStats,
                trend_data: trendData,
                keyword_analysis: keywordAnalysis,
                generated_at: new Date().toISOString()
              }}
              filename="comparative_sentiment_analysis"
            />
          </div>
        </CardHeader>
      </Card>
    </div>
  );
}