import React, { useState, useCallback, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Textarea } from './ui/textarea'
import { Alert, AlertDescription } from './ui/alert'
import { Progress } from './ui/progress'
import { Badge } from './ui/badge'
import { Separator } from './ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs'
import { 
  Upload, 
  FileText, 
  X, 
  CheckCircle, 
  AlertCircle,
  Download,
  Eye,
  FileSpreadsheet,
  FileJson,
  Trash2
} from 'lucide-react'

interface TextInputProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  label?: string
  description?: string
  supportsBatch?: boolean
  acceptedFormats?: string[]
  maxFileSize?: number // in MB
  className?: string
}

interface FileInfo {
  file: File
  content: string
  lineCount: number
  preview: string[]
  format: 'txt' | 'csv' | 'json' | 'unknown'
}

export function TextInput({
  value,
  onChange,
  placeholder = "Enter your text here...",
  label = "Text Input",
  description,
  supportsBatch = false,
  acceptedFormats = ['.txt', '.csv', '.json'],
  maxFileSize = 10,
  className = ""
}: TextInputProps) {
  const [dragActive, setDragActive] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingProgress, setProcessingProgress] = useState(0)
  const [uploadedFile, setUploadedFile] = useState<FileInfo | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [activeInputType, setActiveInputType] = useState<'direct' | 'file'>('direct')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const clearError = () => setError(null)
  const clearFile = () => {
    setUploadedFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  // File type detection
  const detectFileFormat = (file: File, content: string): FileInfo['format'] => {
    const extension = file.name.toLowerCase().split('.').pop()
    
    if (extension === 'json') {
      try {
        JSON.parse(content)
        return 'json'
      } catch {
        return 'unknown'
      }
    }
    
    if (extension === 'csv' || content.includes(',') || content.includes('\t')) {
      return 'csv'
    }
    
    if (extension === 'txt' || typeof content === 'string') {
      return 'txt'
    }
    
    return 'unknown'
  }

  // Parse different file formats
  const parseFileContent = (content: string, format: FileInfo['format']): string => {
    switch (format) {
      case 'csv':
        // Parse CSV and treat each row as a separate text
        const lines = content.split('\n').filter(line => line.trim())
        if (lines.length > 0) {
          // Check if first line looks like headers
          const firstLine = lines[0]
          const hasHeaders = firstLine.toLowerCase().includes('text') || 
                           firstLine.toLowerCase().includes('content') ||
                           firstLine.toLowerCase().includes('review')
          
          const dataLines = hasHeaders ? lines.slice(1) : lines
          
          // Extract text from CSV (assume first column or find text column)
          return dataLines.map(line => {
            const columns = line.split(',').map(col => col.trim().replace(/^["']|["']$/g, ''))
            // Return the first non-empty column or the longest column
            return columns.length > 0 ? 
              columns.find(col => col.length > 0) || columns[0] : 
              line
          }).filter(text => text && text.length > 0).join('\n')
        }
        return content
        
      case 'json':
        try {
          const parsed = JSON.parse(content)
          if (Array.isArray(parsed)) {
            // Array of strings or objects with text property
            return parsed.map(item => 
              typeof item === 'string' ? item : 
              item.text || item.content || item.review || JSON.stringify(item)
            ).join('\n')
          } else if (parsed.data && Array.isArray(parsed.data)) {
            // Object with data array
            return parsed.data.map((item: any) => 
              typeof item === 'string' ? item : 
              item.text || item.content || item.review || JSON.stringify(item)
            ).join('\n')
          } else {
            // Single object
            return parsed.text || parsed.content || parsed.review || JSON.stringify(parsed)
          }
        } catch {
          return content
        }
        
      case 'txt':
      default:
        return content
    }
  }

  // File processing
  const processFile = async (file: File): Promise<void> => {
    setIsProcessing(true)
    setProcessingProgress(0)
    setError(null)

    try {
      // Validate file size
      if (file.size > maxFileSize * 1024 * 1024) {
        throw new Error(`File size exceeds ${maxFileSize}MB limit`)
      }

      // Validate file type
      const fileExtension = '.' + file.name.toLowerCase().split('.').pop()
      if (!acceptedFormats.includes(fileExtension)) {
        throw new Error(`File type not supported. Accepted formats: ${acceptedFormats.join(', ')}`)
      }

      // Read file with progress simulation
      const progressInterval = setInterval(() => {
        setProcessingProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + Math.random() * 20
        })
      }, 100)

      const content = await file.text()
      clearInterval(progressInterval)
      setProcessingProgress(100)

      const format = detectFileFormat(file, content)
      const parsedContent = parseFileContent(content, format)
      const lines = parsedContent.split('\n').filter(line => line.trim())
      
      const fileInfo: FileInfo = {
        file,
        content: parsedContent,
        lineCount: lines.length,
        preview: lines.slice(0, 3), // First 3 lines for preview
        format
      }

      setUploadedFile(fileInfo)
      onChange(parsedContent)
      
      setTimeout(() => {
        setProcessingProgress(0)
        setIsProcessing(false)
      }, 500)
      
    } catch (error) {
      setProcessingProgress(0)
      setIsProcessing(false)
      const errorMessage = error instanceof Error ? error.message : 'Failed to process file'
      setError(errorMessage)
    }
  }

  // Drag and drop handlers
  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true)
    } else if (e.type === 'dragleave') {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    clearError()

    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      processFile(files[0])
      setActiveInputType('file')
    }
  }, [])

  // File input change handler
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    clearError()
    const file = e.target.files?.[0]
    if (file) {
      processFile(file)
      setActiveInputType('file')
    }
  }

  // Use uploaded file content
  const useFileContent = () => {
    if (uploadedFile) {
      onChange(uploadedFile.content)
      setActiveInputType('file')
    }
  }

  // Clear all and switch to direct input
  const switchToDirectInput = () => {
    setActiveInputType('direct')
    clearFile()
    clearError()
  }

  const getFormatIcon = (format: FileInfo['format']) => {
    switch (format) {
      case 'csv': return FileSpreadsheet
      case 'json': return FileJson
      case 'txt': return FileText
      default: return FileText
    }
  }

  const getFormatColor = (format: FileInfo['format']) => {
    switch (format) {
      case 'csv': return 'text-green-600'
      case 'json': return 'text-blue-600'
      case 'txt': return 'text-gray-600'
      default: return 'text-gray-600'
    }
  }

  return (
    <div className={`space-y-4 ${className}`}>
      <div>
        <Label className="text-base font-medium">{label}</Label>
        {description && (
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        )}
      </div>

      <Tabs value={activeInputType} onValueChange={(value) => setActiveInputType(value as 'direct' | 'file')}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="direct">Direct Entry</TabsTrigger>
          <TabsTrigger value="file">File Upload</TabsTrigger>
        </TabsList>

        {/* Direct Text Entry */}
        <TabsContent value="direct" className="space-y-4">
          <Textarea
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="min-h-[120px] resize-y"
          />
          
          {supportsBatch && value && (
            <div className="text-sm text-gray-600">
              <Badge variant="outline">
                {value.split('\n').filter(line => line.trim()).length} lines detected
              </Badge>
            </div>
          )}
        </TabsContent>

        {/* File Upload */}
        <TabsContent value="file" className="space-y-4">
          {/* Drag and Drop Area */}
          <div
            className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive 
                ? 'border-primary bg-primary/5' 
                : 'border-gray-300 hover:border-gray-400'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="space-y-4">
              <div className="mx-auto w-12 h-12 text-gray-400">
                <Upload className="w-full h-full" />
              </div>
              
              <div>
                <p className="text-lg font-medium">
                  {dragActive ? 'Drop your file here' : 'Drag and drop your file here'}
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  or click to browse files
                </p>
              </div>
              
              <div className="flex flex-wrap justify-center gap-2">
                {acceptedFormats.map(format => (
                  <Badge key={format} variant="secondary" className="text-xs">
                    {format}
                  </Badge>
                ))}
              </div>
              
              <Button 
                variant="outline" 
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessing}
              >
                Choose File
              </Button>
              
              {/* Use regular HTML input instead of Input component to avoid ref issues */}
              <input
                ref={fileInputRef}
                type="file"
                accept={acceptedFormats.join(',')}
                onChange={handleFileInputChange}
                style={{ display: 'none' }}
              />
            </div>
          </div>

          {/* Processing Progress */}
          {isProcessing && (
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Processing file...</span>
                    <span>{Math.round(processingProgress)}%</span>
                  </div>
                  <Progress value={processingProgress} />
                </div>
              </CardContent>
            </Card>
          )}

          {/* File Preview */}
          {uploadedFile && !isProcessing && (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    {React.createElement(getFormatIcon(uploadedFile.format), {
                      className: `w-4 h-4 ${getFormatColor(uploadedFile.format)}`
                    })}
                    File Preview
                  </CardTitle>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={clearFile}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <CardDescription>
                  {uploadedFile.file.name} • {uploadedFile.lineCount} lines • {(uploadedFile.file.size / 1024).toFixed(1)} KB
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="bg-gray-50 rounded p-3 text-sm">
                  {uploadedFile.preview.map((line, index) => (
                    <div key={index} className="truncate text-gray-700">
                      {index + 1}. {line}
                    </div>
                  ))}
                  {uploadedFile.lineCount > 3 && (
                    <div className="text-gray-500 italic">
                      ... and {uploadedFile.lineCount - 3} more lines
                    </div>
                  )}
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    onClick={useFileContent}
                    size="sm"
                    className="flex-1"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Use This Content
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={clearFile}
                    size="sm"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Remove
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Error Display */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Format Guidelines */}
      {activeInputType === 'file' && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">File Format Guidelines</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-gray-600">
            <div className="grid gap-2">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-gray-600" />
                <span><strong>.txt:</strong> One text per line for batch processing</span>
              </div>
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-green-600" />
                <span><strong>.csv:</strong> Text data in columns (auto-detects text column)</span>
              </div>
              <div className="flex items-center gap-2">
                <FileJson className="w-4 h-4 text-blue-600" />
                <span><strong>.json:</strong> Array of strings or objects with text properties</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}