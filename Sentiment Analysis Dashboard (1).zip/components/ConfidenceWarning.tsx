import React from 'react'
import { Alert, AlertDescription } from './ui/alert'
import { Badge } from './ui/badge'
import { AlertTriangle, Info, CheckCircle } from 'lucide-react'

interface ConfidenceWarningProps {
  confidence: number
  variant?: 'inline' | 'alert' | 'badge'
  showIcon?: boolean
}

export function ConfidenceWarning({ 
  confidence, 
  variant = 'alert', 
  showIcon = true 
}: ConfidenceWarningProps) {
  const confidencePercent = Math.round(confidence * 100)
  
  const getConfidenceLevel = () => {
    if (confidence >= 0.8) return 'high'
    if (confidence >= 0.6) return 'medium'
    return 'low'
  }

  const getConfidenceColor = () => {
    const level = getConfidenceLevel()
    switch (level) {
      case 'high': return 'text-green-600'
      case 'medium': return 'text-yellow-600'
      case 'low': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const getConfidenceIcon = () => {
    const level = getConfidenceLevel()
    switch (level) {
      case 'high': return CheckCircle
      case 'medium': return Info
      case 'low': return AlertTriangle
      default: return Info
    }
  }

  const getConfidenceMessage = () => {
    const level = getConfidenceLevel()
    switch (level) {
      case 'high': 
        return 'High confidence prediction - generally reliable'
      case 'medium': 
        return 'Medium confidence prediction - review context for accuracy'
      case 'low': 
        return 'Low confidence prediction - manual review recommended. The model is uncertain about this classification.'
      default: 
        return 'Confidence level unknown'
    }
  }

  if (variant === 'badge') {
    const level = getConfidenceLevel()
    const IconComponent = getConfidenceIcon()
    return (
      <Badge 
        variant={level === 'low' ? 'destructive' : level === 'medium' ? 'secondary' : 'default'}
        className="flex items-center gap-1"
      >
        {showIcon && <IconComponent className="w-3 h-3" />}
        {confidencePercent}% confidence
      </Badge>
    )
  }

  if (variant === 'inline') {
    const IconComponent = getConfidenceIcon()
    return (
      <div className={`flex items-center gap-1 text-sm ${getConfidenceColor()}`}>
        {showIcon && <IconComponent className="w-4 h-4" />}
        <span>{confidencePercent}% confidence</span>
        {getConfidenceLevel() === 'low' && (
          <span className="text-xs text-gray-500">- Review recommended</span>
        )}
      </div>
    )
  }

  // Alert variant
  const level = getConfidenceLevel()
  
  if (level === 'low') {
    return (
      <Alert variant="destructive" className="mt-2">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>Low Confidence ({confidencePercent}%):</strong> {getConfidenceMessage()}
        </AlertDescription>
      </Alert>
    )
  }

  if (level === 'medium') {
    return (
      <Alert className="mt-2">
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>Medium Confidence ({confidencePercent}%):</strong> {getConfidenceMessage()}
        </AlertDescription>
      </Alert>
    )
  }

  // Don't show alert for high confidence
  return null
}