import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Alert, AlertDescription } from './ui/alert'
import { Badge } from './ui/badge'
import { Button } from './ui/button'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible'
import { Separator } from './ui/separator'
import { 
  AlertTriangle, 
  Info, 
  Brain, 
  ExternalLink, 
  ChevronDown,
  ChevronUp,
  Target,
  TrendingDown,
  MessageCircle,
  Globe
} from 'lucide-react'

export function ModelInfoPanel() {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="w-5 h-5" />
          AI Model Information & Guidelines
        </CardTitle>
        <CardDescription>
          Understanding model capabilities, limitations, and best practices for sentiment analysis
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Key Warnings - Always Visible */}
        <div className="grid gap-3">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Probabilistic Models:</strong> AI sentiment analysis is probabilistic, not deterministic. 
              Occasional misclassifications are normal and expected, especially with complex or ambiguous text.
            </AlertDescription>
          </Alert>
          
          <Alert>
            <Target className="h-4 w-4" />
            <AlertDescription>
              <strong>Confidence Threshold:</strong> Results with confidence below 60% should be reviewed carefully. 
              Low confidence often indicates ambiguous sentiment or challenging text.
            </AlertDescription>
          </Alert>
        </div>

        {/* Expandable Detailed Information */}
        <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
          <CollapsibleTrigger asChild>
            <Button variant="outline" className="w-full justify-between">
              <span>Detailed Model Information</span>
              {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </Button>
          </CollapsibleTrigger>
          
          <CollapsibleContent className="space-y-4 mt-4">
            {/* Current Model Section */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-600" />
                <h4 className="font-medium">Current Model</h4>
              </div>
              <div className="pl-6 space-y-2 text-sm text-gray-600">
                <p>
                  <strong>Demo Model:</strong> Simplified keyword-based sentiment analysis for demonstration purposes
                </p>
                <p>
                  <strong>Production Alternative:</strong> Consider models like BERT, RoBERTa, or DistilBERT fine-tuned for sentiment analysis
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Keyword-based</Badge>
                  <Badge variant="secondary">Demo Only</Badge>
                  <Badge variant="secondary">English Optimized</Badge>
                </div>
              </div>
            </div>

            <Separator />

            {/* Neutral Class Ambiguity */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-orange-600" />
                <h4 className="font-medium">Neutral Class Challenges</h4>
              </div>
              <div className="pl-6 space-y-2 text-sm text-gray-600">
                <p>
                  The neutral sentiment class is often the most ambiguous and challenging to classify accurately:
                </p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Factual statements may be misclassified as neutral when they contain subtle sentiment</li>
                  <li>Mixed sentiment text (both positive and negative elements) often defaults to neutral</li>
                  <li>Context-dependent sentiment may appear neutral without sufficient context</li>
                  <li>Short texts with minimal emotional indicators frequently classify as neutral</li>
                </ul>
              </div>
            </div>

            <Separator />

            {/* Language Limitations */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-purple-600" />
                <h4 className="font-medium">Language & Style Limitations</h4>
              </div>
              <div className="pl-6 space-y-2 text-sm text-gray-600">
                <p>
                  Several language patterns can significantly impact accuracy:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                  <div>
                    <p className="font-medium text-red-600 mb-1">Challenging for AI:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>Sarcasm and irony</li>
                      <li>Cultural references</li>
                      <li>Domain-specific jargon</li>
                      <li>Implicit sentiment</li>
                      <li>Negation patterns</li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium text-green-600 mb-1">Generally Reliable:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>Clear emotional language</li>
                      <li>Standard vocabulary</li>
                      <li>Direct opinions</li>
                      <li>Formal text</li>
                      <li>Product reviews</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Confidence Score Guide */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-green-600" />
                <h4 className="font-medium">Confidence Score Interpretation</h4>
              </div>
              <div className="pl-6 space-y-2">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                  <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                    <p className="font-medium text-green-800">High Confidence</p>
                    <p className="text-green-600">≥ 80%</p>
                    <p className="text-xs text-green-600 mt-1">Generally reliable prediction</p>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                    <p className="font-medium text-yellow-800">Medium Confidence</p>
                    <p className="text-yellow-600">60% - 79%</p>
                    <p className="text-xs text-yellow-600 mt-1">Reasonable prediction, review context</p>
                  </div>
                  <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                    <p className="font-medium text-red-800">Low Confidence</p>
                    <p className="text-red-600">&lt; 60%</p>
                    <p className="text-xs text-red-600 mt-1">Uncertain prediction, manual review recommended</p>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Best Practices */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-600" />
                <h4 className="font-medium">Best Practices</h4>
              </div>
              <div className="pl-6 space-y-2 text-sm text-gray-600">
                <ul className="list-disc list-inside space-y-1">
                  <li>Use sentiment analysis for trends and patterns, not absolute truth</li>
                  <li>Always review low-confidence predictions manually</li>
                  <li>Consider domain-specific fine-tuning for specialized text</li>
                  <li>Combine with human expertise for critical decisions</li>
                  <li>Test with representative samples before production use</li>
                </ul>
              </div>
            </div>

            <Separator />

            {/* External Resources */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-600" />
                <h4 className="font-medium">Resources & Documentation</h4>
              </div>
              <div className="pl-6 space-y-2">
                <div className="grid gap-2">
                  <a 
                    href="https://huggingface.co/cardiffnlp/twitter-roberta-base-sentiment-latest"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3" />
                    RoBERTa Sentiment Model (Hugging Face)
                  </a>
                  <a 
                    href="https://huggingface.co/distilbert-base-uncased-finetuned-sst-2-english"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3" />
                    DistilBERT Sentiment Model (Hugging Face)
                  </a>
                  <a 
                    href="https://aws.amazon.com/comprehend/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3" />
                    AWS Comprehend Sentiment Analysis
                  </a>
                  <a 
                    href="https://developers.google.com/machine-learning/guides/text-classification"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3" />
                    Google ML Text Classification Guide
                  </a>
                </div>
              </div>
            </div>

            {/* Data Privacy Note */}
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>Data Privacy:</strong> This demo processes text locally. In production environments, 
                review data handling policies and ensure compliance with privacy regulations (GDPR, CCPA, etc.).
              </AlertDescription>
            </Alert>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  )
}