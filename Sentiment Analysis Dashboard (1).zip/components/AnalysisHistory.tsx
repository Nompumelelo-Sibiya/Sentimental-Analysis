import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { ScrollArea } from './ui/scroll-area'
import { Alert, AlertDescription } from './ui/alert'
import { Skeleton } from './ui/skeleton'
import { ExportModal } from './ExportModal'
import { useAuth } from '../contexts/AuthContext'
import { api, SentimentAnalysis } from '../utils/api'
import { 
  History, 
  Download, 
  Trash2, 
  Eye, 
  AlertCircle,
  Calendar,
  TrendingUp,
  FileText,
  ChevronDown
} from 'lucide-react'

interface AnalysisHistoryProps {
  onLoadAnalysis?: (analysis: SentimentAnalysis) => void
}

export function AnalysisHistory({ onLoadAnalysis }: AnalysisHistoryProps) {
  const { accessToken, user } = useAuth()
  const [analyses, setAnalyses] = useState<SentimentAnalysis[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  useEffect(() => {
    loadHistory()
  }, [accessToken])

  const loadHistory = async () => {
    try {
      setIsLoading(true)
      setError(null)
      const response = await api.getAnalysisHistory(accessToken || undefined)
      setAnalyses(response.analyses)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load analysis history'
      console.error('Load history error:', errorMessage)
      setError(errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async (analysisId: string) => {
    if (!confirm('Are you sure you want to delete this analysis?')) {
      return
    }

    try {
      setDeletingId(analysisId)
      await api.deleteAnalysis(analysisId, accessToken || undefined)
      setAnalyses(prev => prev.filter(analysis => analysis.id !== analysisId))
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete analysis'
      console.error('Delete analysis error:', errorMessage)
      alert(errorMessage)
    } finally {
      setDeletingId(null)
    }
  }

  const handleViewAnalysis = (analysis: SentimentAnalysis) => {
    if (onLoadAnalysis) {
      onLoadAnalysis(analysis)
    }
  }

  const getSentimentBadgeVariant = (sentiment: string) => {
    switch (sentiment.toLowerCase()) {
      case 'positive':
        return 'default' // green
      case 'negative':
        return 'destructive' // red
      case 'neutral':
        return 'secondary' // gray
      default:
        return 'outline'
    }
  }

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getAnalysisType = (analysis: SentimentAnalysis) => {
    if (analysis.text && analysis.results) {
      return 'Single Text'
    } else if (analysis.batchResults) {
      return 'Batch Analysis'
    } else {
      return 'Analysis'
    }
  }

  const getExportFilename = (analysis: SentimentAnalysis) => {
    const type = getAnalysisType(analysis).toLowerCase().replace(' ', '-')
    const date = new Date(analysis.timestamp).toISOString().split('T')[0]
    return `${type}-${analysis.id.slice(0, 8)}-${date}`
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5" />
            Analysis History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-8 w-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="w-5 h-5" />
          Analysis History
        </CardTitle>
        <CardDescription>
          {user ? 'Your saved sentiment analyses' : 'Anonymous session analyses'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {analyses.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No analyses found</p>
            <p className="text-sm">Your analysis history will appear here</p>
          </div>
        ) : (
          <ScrollArea className="h-96">
            <div className="space-y-4">
              {analyses.map((analysis) => (
                <div
                  key={analysis.id}
                  className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-500">
                          {formatDate(analysis.timestamp)}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {getAnalysisType(analysis)}
                        </Badge>
                      </div>
                      
                      {analysis.text && (
                        <p className="text-sm text-gray-700 mb-2 line-clamp-2">
                          {analysis.text}
                        </p>
                      )}

                      {analysis.summary && (
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span>
                            <TrendingUp className="w-4 h-4 inline mr-1" />
                            {analysis.summary.totalAnalyzed} items
                          </span>
                          <span>
                            Avg confidence: {Math.round(analysis.summary.averageConfidence * 100)}%
                          </span>
                        </div>
                      )}

                      {analysis.results && analysis.results.length > 0 && (
                        <div className="flex gap-2 mt-2">
                          <Badge variant={getSentimentBadgeVariant(analysis.results[0].sentiment)}>
                            {analysis.results[0].sentiment}
                          </Badge>
                          <span className="text-sm text-gray-500">
                            {Math.round(analysis.results[0].confidence * 100)}% confidence
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2 mt-3">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleViewAnalysis(analysis)}
                      className="flex-1"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    
                    <ExportModal
                      data={analysis}
                      analysisId={analysis.id}
                      defaultFilename={getExportFilename(analysis)}
                      title="Export Saved Analysis"
                    >
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1"
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Export
                      </Button>
                    </ExportModal>
                    
                    {user && analysis.userId !== 'anonymous' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(analysis.id)}
                        disabled={deletingId === analysis.id}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  )
}