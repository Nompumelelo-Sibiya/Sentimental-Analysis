import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadialBarChart, RadialBar } from 'recharts';

export function SentimentVisualization({ analysis }) {
  const sentimentData = [
    { name: 'Positive', value: analysis.sentiment_scores.positive * 100, color: '#22c55e' },
    { name: 'Negative', value: analysis.sentiment_scores.negative * 100, color: '#ef4444' },
    { name: 'Neutral', value: analysis.sentiment_scores.neutral * 100, color: '#6b7280' }
  ];

  const keywordData = analysis.keywords.slice(0, 8).map(keyword => ({
    name: keyword.word,
    confidence: keyword.confidence * 100,
    sentiment: keyword.sentiment,
    fill: keyword.sentiment === 'positive' ? '#22c55e' : 
          keyword.sentiment === 'negative' ? '#ef4444' : '#6b7280'
  }));

  const confidenceData = [
    { name: 'Confidence', value: analysis.confidence * 100, fill: '#3b82f6' }
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Card>
        <CardHeader>
          <CardTitle>Sentiment Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={sentimentData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
                outerRadius={60}
                fill="#8884d8"
                dataKey="value"
              >
                {sentimentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `${value.toFixed(1)}%`} />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Keyword Confidence</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={keywordData} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" domain={[0, 100]} />
              <YAxis dataKey="name" type="category" width={60} />
              <Tooltip formatter={(value) => `${value.toFixed(1)}%`} />
              <Bar dataKey="confidence" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Analysis Confidence</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <RadialBarChart cx="50%" cy="50%" innerRadius="40%" outerRadius="80%" data={confidenceData}>
              <RadialBar
                minAngle={15}
                label={{ position: 'insideStart', fill: '#fff' }}
                background
                clockWise
                dataKey="value"
              />
              <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="text-2xl">
                {(analysis.confidence * 100).toFixed(1)}%
              </text>
            </RadialBarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}