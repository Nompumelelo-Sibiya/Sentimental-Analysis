import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { ExportResults } from './ExportResults';
import { mockBatchAnalysis } from '../utils/mockApi';
import { Upload, Brain, Download, Trash2 } from 'lucide-react';

export function BatchProcessor({ onAnalysisComplete }) {
  const [texts, setTexts] = useState(['']);
  const [results, setResults] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');

  const addTextInput = () => {
    setTexts([...texts, '']);
  };

  const updateText = (index, value) => {
    const newTexts = [...texts];
    newTexts[index] = value;
    setTexts(newTexts);
  };

  const removeText = (index) => {
    if (texts.length > 1) {
      const newTexts = texts.filter((_, i) => i !== index);
      setTexts(newTexts);
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target.result;
          // Split by double newlines to separate entries
          const entries = content.split('\n\n').filter(entry => entry.trim());
          setTexts(entries);
        };
        reader.readAsText(file);
      } else if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target.result;
          const lines = content.split('\n').filter(line => line.trim());
          // Assume text is in the first column after header
          const entries = lines.slice(1).map(line => {
            const columns = line.split(',');
            return columns[0].replace(/"/g, ''); // Remove quotes
          }).filter(entry => entry.trim());
          setTexts(entries);
        };
        reader.readAsText(file);
      } else {
        setError('Please upload a .txt or .csv file');
      }
    }
  };

  const processBatch = async () => {
    const validTexts = texts.filter(text => text.trim());
    if (validTexts.length === 0) {
      setError('Please enter at least one text to analyze');
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setError('');
    setResults([]);

    try {
      // Simulate processing with progress updates
      for (let i = 0; i < validTexts.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 500)); // Simulate processing time
        setProgress(((i + 1) / validTexts.length) * 100);
      }

      const batchResults = mockBatchAnalysis(validTexts);
      setResults(batchResults);

      // Add each result to history
      batchResults.forEach(result => {
        onAnalysisComplete({
          ...result,
          timestamp: new Date().toISOString(),
          originalText: result.text,
          id: Date.now() + Math.random()
        });
      });

    } catch (err) {
      setError('Failed to process batch. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const getSentimentBadgeVariant = (sentiment) => {
    switch (sentiment) {
      case 'positive': return 'default';
      case 'negative': return 'destructive';
      case 'neutral': return 'secondary';
      default: return 'secondary';
    }
  };

  const exportBatchResults = () => {
    const exportData = {
      batch_analysis: true,
      processed_at: new Date().toISOString(),
      total_texts: results.length,
      results: results,
      summary: {
        positive_count: results.filter(r => r.overall_sentiment === 'positive').length,
        negative_count: results.filter(r => r.overall_sentiment === 'negative').length,
        neutral_count: results.filter(r => r.overall_sentiment === 'neutral').length,
        average_confidence: results.reduce((sum, r) => sum + r.confidence, 0) / results.length
      }
    };

    return exportData;
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <div>
            <input
              type="file"
              accept=".txt,.csv"
              onChange={handleFileUpload}
              className="hidden"
              id="batch-file-upload"
            />
            <label htmlFor="batch-file-upload">
              <Button variant="outline" className="cursor-pointer">
                <Upload className="h-4 w-4 mr-2" />
                Upload Batch File
              </Button>
            </label>
          </div>
          
          <Button onClick={addTextInput} variant="outline">
            Add Text Input
          </Button>
          
          <Button 
            onClick={processBatch} 
            disabled={isProcessing || texts.every(t => !t.trim())}
            className="flex items-center gap-2"
          >
            <Brain className="h-4 w-4" />
            {isProcessing ? 'Processing...' : `Process ${texts.filter(t => t.trim()).length} Texts`}
          </Button>
        </div>

        {isProcessing && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Processing batch...</span>
              <span>{progress.toFixed(0)}%</span>
            </div>
            <Progress value={progress} />
          </div>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-3">
          {texts.map((text, index) => (
            <div key={index} className="flex gap-2">
              <Textarea
                value={text}
                onChange={(e) => updateText(index, e.target.value)}
                placeholder={`Text ${index + 1} for analysis...`}
                className="min-h-20"
              />
              {texts.length > 1 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeText(index)}
                  className="px-2"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      {results.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Batch Analysis Results</CardTitle>
              <ExportResults 
                data={exportBatchResults()}
                filename="batch_sentiment_analysis"
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="mb-4 grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl text-green-600">
                  {results.filter(r => r.overall_sentiment === 'positive').length}
                </div>
                <div className="text-sm text-muted-foreground">Positive</div>
              </div>
              <div>
                <div className="text-2xl text-red-600">
                  {results.filter(r => r.overall_sentiment === 'negative').length}
                </div>
                <div className="text-sm text-muted-foreground">Negative</div>
              </div>
              <div>
                <div className="text-2xl text-gray-600">
                  {results.filter(r => r.overall_sentiment === 'neutral').length}
                </div>
                <div className="text-sm text-muted-foreground">Neutral</div>
              </div>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Text Preview</TableHead>
                  <TableHead>Sentiment</TableHead>
                  <TableHead>Confidence</TableHead>
                  <TableHead>Top Keywords</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result, index) => (
                  <TableRow key={index}>
                    <TableCell className="max-w-xs truncate">
                      {result.text}
                    </TableCell>
                    <TableCell>
                      <Badge variant={getSentimentBadgeVariant(result.overall_sentiment)}>
                        {result.overall_sentiment}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {(result.confidence * 100).toFixed(1)}%
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {result.keywords.slice(0, 3).map((keyword, kidx) => (
                          <Badge key={kidx} variant="outline" className="text-xs">
                            {keyword.word}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}