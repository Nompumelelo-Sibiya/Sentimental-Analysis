import React from 'react';
import { Button } from './ui/button';
import { Download, FileText, FileSpreadsheet } from 'lucide-react';

export function ExportResults({ data, filename = 'sentiment_analysis' }) {
  const exportAsJSON = () => {
    const jsonData = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportAsCSV = () => {
    const csvHeaders = [
      'Overall Sentiment',
      'Confidence',
      'Positive Score',
      'Negative Score',
      'Neutral Score',
      'Keywords',
      'Explanation',
      'Timestamp'
    ];

    const csvRow = [
      data.overall_sentiment,
      (data.confidence * 100).toFixed(2),
      (data.sentiment_scores.positive * 100).toFixed(2),
      (data.sentiment_scores.negative * 100).toFixed(2),
      (data.sentiment_scores.neutral * 100).toFixed(2),
      data.keywords.map(k => `${k.word}(${k.sentiment})`).join('; '),
      `"${data.explanation}"`,
      data.timestamp || new Date().toISOString()
    ];

    const csvContent = [csvHeaders.join(','), csvRow.join(',')].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportAsPDF = () => {
    // Create a formatted text representation for PDF
    const pdfContent = `
SENTIMENT ANALYSIS REPORT
========================

Analysis Date: ${data.timestamp || new Date().toISOString()}

OVERALL SENTIMENT: ${data.overall_sentiment.toUpperCase()}
Confidence: ${(data.confidence * 100).toFixed(2)}%

DETAILED SCORES:
- Positive: ${(data.sentiment_scores.positive * 100).toFixed(2)}%
- Negative: ${(data.sentiment_scores.negative * 100).toFixed(2)}%
- Neutral: ${(data.sentiment_scores.neutral * 100).toFixed(2)}%

KEYWORDS:
${data.keywords.map(k => `- ${k.word} (${k.sentiment}, ${(k.confidence * 100).toFixed(1)}% confidence)`).join('\n')}

EXPLANATION:
${data.explanation}

${data.originalText ? `\nORIGINAL TEXT:\n${data.originalText}` : ''}
    `.trim();

    const blob = new Blob([pdfContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-wrap gap-2">
      <Button onClick={exportAsJSON} variant="outline" size="sm">
        <FileText className="h-4 w-4 mr-2" />
        Export JSON
      </Button>
      <Button onClick={exportAsCSV} variant="outline" size="sm">
        <FileSpreadsheet className="h-4 w-4 mr-2" />
        Export CSV
      </Button>
      <Button onClick={exportAsPDF} variant="outline" size="sm">
        <Download className="h-4 w-4 mr-2" />
        Export TXT
      </Button>
    </div>
  );
}