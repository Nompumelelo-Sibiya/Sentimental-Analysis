import React, { useState } from 'react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { SentimentVisualization } from './SentimentVisualization';
import { ExportResults } from './ExportResults';
import { mockSentimentAnalysis } from '../utils/mockApi';
import { Upload, Brain, Download } from 'lucide-react';

export function TextAnalyzer({ onAnalysisComplete }) {
  const [text, setText] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState('');

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setText(e.target.result);
        };
        reader.readAsText(file);
      } else {
        setError('Please upload a .txt file only');
      }
    }
  };

  const analyzeSentiment = async () => {
    if (!text.trim()) {
      setError('Please enter some text to analyze');
      return;
    }

    setIsAnalyzing(true);
    setError('');
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const result = mockSentimentAnalysis(text);
      setAnalysis(result);
      
      // Add to history with timestamp
      onAnalysisComplete({
        ...result,
        timestamp: new Date().toISOString(),
        originalText: text,
        id: Date.now()
      });
      
    } catch (err) {
      setError('Failed to analyze sentiment. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSentimentColor = (sentiment) => {
    switch (sentiment) {
      case 'positive': return 'bg-green-500';
      case 'negative': return 'bg-red-500';
      case 'neutral': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getSentimentBadgeVariant = (sentiment) => {
    switch (sentiment) {
      case 'positive': return 'default';
      case 'negative': return 'destructive';
      case 'neutral': return 'secondary';
      default: return 'secondary';
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div>
          <label className="block mb-2">Enter text to analyze:</label>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Enter your text here for sentiment analysis..."
            className="min-h-32"
          />
        </div>
        
        <div className="flex items-center gap-4">
          <div>
            <input
              type="file"
              accept=".txt"
              onChange={handleFileUpload}
              className="hidden"
              id="file-upload"
            />
            <label htmlFor="file-upload">
              <Button variant="outline" className="cursor-pointer">
                <Upload className="h-4 w-4 mr-2" />
                Upload Text File
              </Button>
            </label>
          </div>
          
          <Button 
            onClick={analyzeSentiment} 
            disabled={isAnalyzing || !text.trim()}
            className="flex items-center gap-2"
          >
            <Brain className="h-4 w-4" />
            {isAnalyzing ? 'Analyzing...' : 'Analyze Sentiment'}
          </Button>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
      </div>

      {analysis && (
        <div className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Overall Sentiment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <Badge variant={getSentimentBadgeVariant(analysis.overall_sentiment)} className="text-lg px-3 py-1">
                    {analysis.overall_sentiment.toUpperCase()}
                  </Badge>
                  <span className="text-2xl">{(analysis.confidence * 100).toFixed(1)}%</span>
                </div>
                <Progress value={analysis.confidence * 100} className="mt-3" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Sentiment Scores</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {Object.entries(analysis.sentiment_scores).map(([sentiment, score]) => (
                  <div key={sentiment} className="flex justify-between items-center">
                    <span className="capitalize">{sentiment}</span>
                    <div className="flex items-center gap-2">
                      <Progress value={score * 100} className="w-16" />
                      <span className="text-sm">{(score * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Key Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span>Word Count</span>
                  <span>{text.split(' ').filter(w => w.trim()).length}</span>
                </div>
                <div className="flex justify-between">
                  <span>Character Count</span>
                  <span>{text.length}</span>
                </div>
                <div className="flex justify-between">
                  <span>Keywords Found</span>
                  <span>{analysis.keywords.length}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Keyword Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="mb-2">Sentiment-driving Keywords:</h4>
                  <div className="flex flex-wrap gap-2">
                    {analysis.keywords.map((keyword, index) => (
                      <Badge 
                        key={index} 
                        variant={getSentimentBadgeVariant(keyword.sentiment)}
                        className="flex items-center gap-1"
                      >
                        {keyword.word}
                        <span className="text-xs">({(keyword.confidence * 100).toFixed(0)}%)</span>
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="mb-2">Explanation:</h4>
                  <p className="text-sm text-muted-foreground bg-muted p-3 rounded">
                    {analysis.explanation}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <SentimentVisualization analysis={analysis} />
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                Export Results
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ExportResults 
                data={{
                  ...analysis,
                  originalText: text,
                  timestamp: new Date().toISOString()
                }}
                filename="sentiment_analysis"
              />
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}