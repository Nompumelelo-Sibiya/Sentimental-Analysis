import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js'
import * as kv from './kv_store.tsx'

const app = new Hono()

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}))

app.use('*', logger(console.log))

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)

// Create bucket for exported reports on startup
async function initializeBuckets() {
  try {
    const bucketName = 'make-bd15aa81-sentiment-reports'
    const { data: buckets } = await supabase.storage.listBuckets()
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName)
    
    if (!bucketExists) {
      const { error } = await supabase.storage.createBucket(bucketName, {
        public: false
      })
      if (error) {
        console.log(`Error creating bucket: ${error.message}`)
      } else {
        console.log('Successfully created sentiment reports bucket')
      }
    }
  } catch (error) {
    console.log(`Error initializing buckets: ${error}`)
  }
}

// Initialize buckets on startup
initializeBuckets()

// User signup route
app.post('/make-server-bd15aa81/auth/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json()
    
    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400)
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    })

    if (error) {
      console.log(`Signup error: ${error.message}`)
      return c.json({ error: error.message }, 400)
    }

    return c.json({ user: data.user })
  } catch (error) {
    console.log(`Signup error: ${error}`)
    return c.json({ error: 'Internal server error during signup' }, 500)
  }
})

// Save sentiment analysis result
app.post('/make-server-bd15aa81/analysis/save', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    let userId = 'anonymous'
    
    // Check if user is authenticated
    if (accessToken && accessToken !== Deno.env.get('SUPABASE_ANON_KEY')) {
      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      if (user?.id) {
        userId = user.id
      }
    }

    const analysisData = await c.req.json()
    const analysisId = crypto.randomUUID()
    const timestamp = new Date().toISOString()

    const analysisRecord = {
      id: analysisId,
      userId,
      timestamp,
      ...analysisData
    }

    await kv.set(`analysis:${analysisId}`, analysisRecord)
    await kv.set(`user_analysis:${userId}:${timestamp}:${analysisId}`, analysisId)

    return c.json({ 
      success: true, 
      analysisId,
      message: 'Analysis saved successfully' 
    })
  } catch (error) {
    console.log(`Save analysis error: ${error}`)
    return c.json({ error: 'Failed to save analysis' }, 500)
  }
})

// Get user's analysis history
app.get('/make-server-bd15aa81/analysis/history', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    let userId = 'anonymous'
    
    // Check if user is authenticated
    if (accessToken && accessToken !== Deno.env.get('SUPABASE_ANON_KEY')) {
      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      if (user?.id) {
        userId = user.id
      }
    }

    const userAnalysisKeys = await kv.getByPrefix(`user_analysis:${userId}:`)
    const analysisIds = userAnalysisKeys.map(item => item.value)
    
    if (analysisIds.length === 0) {
      return c.json({ analyses: [] })
    }

    const analyses = await kv.mget(analysisIds.map(id => `analysis:${id}`))
    
    // Sort by timestamp, most recent first
    const sortedAnalyses = analyses
      .filter(item => item.value)
      .map(item => item.value)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

    return c.json({ analyses: sortedAnalyses })
  } catch (error) {
    console.log(`Get history error: ${error}`)
    return c.json({ error: 'Failed to retrieve analysis history' }, 500)
  }
})

// Get specific analysis by ID
app.get('/make-server-bd15aa81/analysis/:id', async (c) => {
  try {
    const analysisId = c.req.param('id')
    const analysis = await kv.get(`analysis:${analysisId}`)
    
    if (!analysis) {
      return c.json({ error: 'Analysis not found' }, 404)
    }

    return c.json({ analysis })
  } catch (error) {
    console.log(`Get analysis error: ${error}`)
    return c.json({ error: 'Failed to retrieve analysis' }, 500)
  }
})

// Delete analysis
app.delete('/make-server-bd15aa81/analysis/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    let userId = 'anonymous'
    
    // Check if user is authenticated
    if (accessToken && accessToken !== Deno.env.get('SUPABASE_ANON_KEY')) {
      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      if (user?.id) {
        userId = user.id
      }
    }

    const analysisId = c.req.param('id')
    const analysis = await kv.get(`analysis:${analysisId}`)
    
    if (!analysis) {
      return c.json({ error: 'Analysis not found' }, 404)
    }

    // Check if user owns this analysis
    if (analysis.userId !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    await kv.del(`analysis:${analysisId}`)
    
    // Clean up user analysis reference
    const userAnalysisKeys = await kv.getByPrefix(`user_analysis:${userId}:`)
    const keyToDelete = userAnalysisKeys.find(item => item.value === analysisId)?.key
    
    if (keyToDelete) {
      await kv.del(keyToDelete)
    }

    return c.json({ success: true, message: 'Analysis deleted successfully' })
  } catch (error) {
    console.log(`Delete analysis error: ${error}`)
    return c.json({ error: 'Failed to delete analysis' }, 500)
  }
})

// Enhanced export analysis with multiple formats including PDF
app.post('/make-server-bd15aa81/analysis/export', async (c) => {
  try {
    const { analysisId, format, includeCharts } = await c.req.json()
    
    if (!analysisId || !format) {
      return c.json({ error: 'Analysis ID and format are required' }, 400)
    }

    if (!['json', 'csv', 'pdf'].includes(format)) {
      return c.json({ error: 'Unsupported format. Use json, csv, or pdf' }, 400)
    }

    const analysis = await kv.get(`analysis:${analysisId}`)
    
    if (!analysis) {
      return c.json({ error: 'Analysis not found' }, 404)
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
    const fileName = `sentiment-analysis-${analysisId.slice(0, 8)}-${timestamp}.${format}`
    let fileContent: string | Uint8Array
    let contentType: string

    switch (format) {
      case 'json':
        fileContent = JSON.stringify(analysis, null, 2)
        contentType = 'application/json'
        break
      case 'csv':
        fileContent = generateCSV(analysis)
        contentType = 'text/csv'
        break
      case 'pdf':
        fileContent = await generatePDF(analysis, includeCharts)
        contentType = 'application/pdf'
        break
      default:
        return c.json({ error: 'Unsupported format' }, 400)
    }

    // Upload to Supabase Storage
    const bucketName = 'make-bd15aa81-sentiment-reports'
    const uploadData = typeof fileContent === 'string' 
      ? new Uint8Array(new TextEncoder().encode(fileContent))
      : fileContent

    const { data: uploadDataResult, error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(fileName, uploadData, {
        contentType,
        upsert: true
      })

    if (uploadError) {
      console.log(`Upload error: ${uploadError.message}`)
      return c.json({ error: 'Failed to upload report' }, 500)
    }

    // Create signed URL for download
    const { data: signedUrlData, error: signedUrlError } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(fileName, 3600) // 1 hour expiry

    if (signedUrlError) {
      console.log(`Signed URL error: ${signedUrlError.message}`)
      return c.json({ error: 'Failed to create download link' }, 500)
    }

    return c.json({ 
      success: true, 
      downloadUrl: signedUrlData.signedUrl,
      fileName,
      format 
    })
  } catch (error) {
    console.log(`Export error: ${error}`)
    return c.json({ error: 'Failed to export analysis' }, 500)
  }
})

// Generate CSV content
function generateCSV(analysis: any): string {
  const headers = ['Text', 'Sentiment', 'Confidence', 'Positive', 'Negative', 'Neutral', 'Keywords']
  const rows = [headers.join(',')]
  
  const results = analysis.results || analysis.batchResults || []
  
  results.forEach((result: any) => {
    const row = [
      `"${result.text.replace(/"/g, '""')}"`,
      result.sentiment,
      result.confidence.toFixed(3),
      result.scores.positive.toFixed(3),
      result.scores.negative.toFixed(3),
      result.scores.neutral.toFixed(3),
      `"${(result.keywords || []).join(', ')}"`
    ]
    rows.push(row.join(','))
  })
  
  // Add summary if available
  if (analysis.summary) {
    rows.push('')
    rows.push('SUMMARY')
    rows.push(`Total Analyzed,${analysis.summary.totalAnalyzed}`)
    rows.push(`Average Confidence,${analysis.summary.averageConfidence.toFixed(3)}`)
    rows.push(`Positive Count,${analysis.summary.sentimentDistribution.positive}`)
    rows.push(`Negative Count,${analysis.summary.sentimentDistribution.negative}`)
    rows.push(`Neutral Count,${analysis.summary.sentimentDistribution.neutral}`)
  }
  
  return rows.join('\n')
}

// Generate PDF content
async function generatePDF(analysis: any, includeCharts: boolean = false): Promise<Uint8Array> {
  // Create a simple PDF report using HTML-like content
  // Since we can't use jsPDF in this environment, we'll create a text-based PDF structure
  
  const results = analysis.results || analysis.batchResults || []
  const timestamp = new Date(analysis.timestamp).toLocaleDateString()
  
  let pdfContent = `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
>>
endobj

4 0 obj
<<
/Length ${calculateContentLength()}
>>
stream
BT
/F1 18 Tf
50 750 Td
(Sentiment Analysis Report) Tj
0 -30 Td
/F1 12 Tf
(Generated on: ${timestamp}) Tj
0 -40 Td
(Analysis ID: ${analysis.id.slice(0, 8)}) Tj
0 -30 Td
`

  if (analysis.summary) {
    pdfContent += `
(SUMMARY) Tj
0 -20 Td
(Total Analyzed: ${analysis.summary.totalAnalyzed}) Tj
0 -15 Td
(Average Confidence: ${(analysis.summary.averageConfidence * 100).toFixed(1)}%) Tj
0 -15 Td
(Positive: ${analysis.summary.sentimentDistribution.positive}) Tj
0 -15 Td
(Negative: ${analysis.summary.sentimentDistribution.negative}) Tj
0 -15 Td
(Neutral: ${analysis.summary.sentimentDistribution.neutral}) Tj
0 -30 Td
`
  }

  pdfContent += `(DETAILED RESULTS) Tj
0 -20 Td
`

  // Add up to 20 results to avoid PDF size issues
  const maxResults = Math.min(results.length, 20)
  for (let i = 0; i < maxResults; i++) {
    const result = results[i]
    const text = result.text.length > 60 ? result.text.slice(0, 60) + '...' : result.text
    pdfContent += `
(${i + 1}. ${text.replace(/[()]/g, '')}) Tj
0 -12 Td
(   Sentiment: ${result.sentiment} \\(${(result.confidence * 100).toFixed(1)}%\\)) Tj
0 -12 Td
(   Scores - P: ${(result.scores.positive * 100).toFixed(1)}% N: ${(result.scores.negative * 100).toFixed(1)}% Neu: ${(result.scores.neutral * 100).toFixed(1)}%) Tj
0 -18 Td
`
  }

  if (results.length > 20) {
    pdfContent += `(... and ${results.length - 20} more results) Tj`
  }

  pdfContent += `
ET
endstream
endobj

xref
0 5
0000000000 65535 f 
0000000015 00000 n 
0000000074 00000 n 
0000000131 00000 n 
0000000210 00000 n 
trailer
<<
/Size 5
/Root 1 0 R
>>
startxref
${1000 + pdfContent.length}
%%EOF`

  function calculateContentLength(): number {
    // Approximate content length calculation
    return 500 + (results.length * 150)
  }

  return new Uint8Array(new TextEncoder().encode(pdfContent))
}

// Enhanced direct export route for frontend usage
app.post('/make-server-bd15aa81/export/direct', async (c) => {
  try {
    const { data, format, filename, includeCharts } = await c.req.json()
    
    if (!data || !format) {
      return c.json({ error: 'Data and format are required' }, 400)
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
    const fileName = `${filename || 'sentiment-analysis'}-${timestamp}.${format}`
    let fileContent: string | Uint8Array
    let contentType: string

    switch (format) {
      case 'json':
        fileContent = JSON.stringify(data, null, 2)
        contentType = 'application/json'
        break
      case 'csv':
        fileContent = generateCSVFromData(data)
        contentType = 'text/csv'
        break
      case 'pdf':
        fileContent = await generatePDFFromData(data, includeCharts)
        contentType = 'application/pdf'
        break
      default:
        return c.json({ error: 'Unsupported format' }, 400)
    }

    // Upload to Supabase Storage
    const bucketName = 'make-bd15aa81-sentiment-reports'
    const uploadData = typeof fileContent === 'string' 
      ? new Uint8Array(new TextEncoder().encode(fileContent))
      : fileContent

    const { data: uploadDataResult, error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(fileName, uploadData, {
        contentType,
        upsert: true
      })

    if (uploadError) {
      console.log(`Upload error: ${uploadError.message}`)
      return c.json({ error: 'Failed to upload report' }, 500)
    }

    // Create signed URL for download
    const { data: signedUrlData, error: signedUrlError } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(fileName, 3600)

    if (signedUrlError) {
      console.log(`Signed URL error: ${signedUrlError.message}`)
      return c.json({ error: 'Failed to create download link' }, 500)
    }

    return c.json({ 
      success: true, 
      downloadUrl: signedUrlData.signedUrl,
      fileName,
      format 
    })
  } catch (error) {
    console.log(`Direct export error: ${error}`)
    return c.json({ error: 'Failed to export data' }, 500)
  }
})

// Generate CSV from raw data
function generateCSVFromData(data: any): string {
  if (data.results || data.batchResults) {
    return generateCSV(data)
  }
  
  // Handle array of results
  if (Array.isArray(data)) {
    const headers = ['Text', 'Sentiment', 'Confidence', 'Positive', 'Negative', 'Neutral', 'Keywords']
    const rows = [headers.join(',')]
    
    data.forEach((result: any) => {
      const row = [
        `"${result.text.replace(/"/g, '""')}"`,
        result.sentiment,
        result.confidence.toFixed(3),
        result.scores.positive.toFixed(3),
        result.scores.negative.toFixed(3),
        result.scores.neutral.toFixed(3),
        `"${(result.keywords || []).join(', ')}"`
      ]
      rows.push(row.join(','))
    })
    
    return rows.join('\n')
  }
  
  return JSON.stringify(data, null, 2)
}

// Generate PDF from raw data
async function generatePDFFromData(data: any, includeCharts: boolean = false): Promise<Uint8Array> {
  if (data.results || data.batchResults) {
    return generatePDF(data, includeCharts)
  }
  
  // Handle array of results
  if (Array.isArray(data)) {
    const mockAnalysis = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      results: data
    }
    return generatePDF(mockAnalysis, includeCharts)
  }
  
  // Fallback: convert to text
  const textContent = JSON.stringify(data, null, 2)
  return new Uint8Array(new TextEncoder().encode(textContent))
}

// Health check
app.get('/make-server-bd15aa81/health', (c) => {
  return c.json({ status: 'healthy', timestamp: new Date().toISOString() })
})

Deno.serve(app.fetch)