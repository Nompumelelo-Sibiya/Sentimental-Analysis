// Mock sentiment analysis API responses
export function mockSentimentAnalysis(text) {
  // Simulate processing delay
  const words = text.toLowerCase().split(/\s+/);
  
  // Define sentiment keywords
  const positiveWords = ['great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'love', 'perfect', 'outstanding', 'brilliant', 'awesome', 'superb', 'magnificent', 'good', 'happy', 'pleased', 'satisfied', 'delighted', 'thrilled'];
  const negativeWords = ['terrible', 'awful', 'horrible', 'bad', 'worst', 'hate', 'disgusting', 'disappointing', 'poor', 'useless', 'annoying', 'frustrating', 'sad', 'angry', 'upset', 'dissatisfied', 'unhappy'];
  const neutralWords = ['okay', 'fine', 'average', 'normal', 'standard', 'typical', 'usual', 'regular', 'common', 'ordinary'];

  // Calculate sentiment scores
  let positiveCount = 0;
  let negativeCount = 0;
  let neutralCount = 0;
  
  const foundKeywords = [];

  words.forEach(word => {
    const cleanWord = word.replace(/[^\w]/g, '');
    if (positiveWords.includes(cleanWord)) {
      positiveCount++;
      foundKeywords.push({
        word: cleanWord,
        sentiment: 'positive',
        confidence: 0.7 + Math.random() * 0.3
      });
    } else if (negativeWords.includes(cleanWord)) {
      negativeCount++;
      foundKeywords.push({
        word: cleanWord,
        sentiment: 'negative',
        confidence: 0.7 + Math.random() * 0.3
      });
    } else if (neutralWords.includes(cleanWord)) {
      neutralCount++;
      foundKeywords.push({
        word: cleanWord,
        sentiment: 'neutral',
        confidence: 0.6 + Math.random() * 0.2
      });
    }
  });

  // Add some random context-aware keywords
  if (text.includes('!')) {
    foundKeywords.push({
      word: 'exclamation',
      sentiment: positiveCount > negativeCount ? 'positive' : 'negative',
      confidence: 0.5 + Math.random() * 0.3
    });
  }

  // Calculate overall sentiment
  const totalSentimentWords = positiveCount + negativeCount + neutralCount;
  const basePositive = totalSentimentWords > 0 ? positiveCount / totalSentimentWords : 0.33;
  const baseNegative = totalSentimentWords > 0 ? negativeCount / totalSentimentWords : 0.33;
  const baseNeutral = totalSentimentWords > 0 ? neutralCount / totalSentimentWords : 0.34;

  // Add some randomness and normalization
  const positive = Math.max(0.05, Math.min(0.95, basePositive + (Math.random() - 0.5) * 0.2));
  const negative = Math.max(0.05, Math.min(0.95, baseNegative + (Math.random() - 0.5) * 0.2));
  const neutral = Math.max(0.05, Math.min(0.95, 1 - positive - negative));

  // Normalize scores
  const total = positive + negative + neutral;
  const normalizedScores = {
    positive: positive / total,
    negative: negative / total,
    neutral: neutral / total
  };

  // Determine overall sentiment
  const maxScore = Math.max(normalizedScores.positive, normalizedScores.negative, normalizedScores.neutral);
  let overallSentiment = 'neutral';
  if (normalizedScores.positive === maxScore) overallSentiment = 'positive';
  else if (normalizedScores.negative === maxScore) overallSentiment = 'negative';

  const confidence = maxScore;

  // Generate explanation
  const explanation = generateExplanation(overallSentiment, foundKeywords, confidence);

  return {
    overall_sentiment: overallSentiment,
    confidence: confidence,
    sentiment_scores: normalizedScores,
    keywords: foundKeywords.slice(0, 10), // Limit to top 10 keywords
    explanation: explanation,
    processed_at: new Date().toISOString()
  };
}

function generateExplanation(sentiment, keywords, confidence) {
  const confidenceLevel = confidence > 0.7 ? 'high' : confidence > 0.5 ? 'moderate' : 'low';
  
  let explanation = `This text was classified as ${sentiment} with ${confidenceLevel} confidence (${(confidence * 100).toFixed(1)}%). `;
  
  if (keywords.length > 0) {
    const sentimentWords = keywords.filter(k => k.sentiment === sentiment);
    if (sentimentWords.length > 0) {
      explanation += `Key indicators include words like "${sentimentWords.slice(0, 3).map(k => k.word).join('", "')}" which strongly suggest ${sentiment} sentiment. `;
    }
  }
  
  if (confidence < 0.6) {
    explanation += `The lower confidence score suggests the text contains mixed sentiment indicators or neutral language.`;
  } else if (confidence > 0.8) {
    explanation += `The high confidence score indicates clear sentiment indicators throughout the text.`;
  }
  
  return explanation;
}

export function mockBatchAnalysis(texts) {
  return texts.map((text, index) => ({
    id: index,
    text: text.substring(0, 100) + (text.length > 100 ? '...' : ''),
    ...mockSentimentAnalysis(text)
  }));
}