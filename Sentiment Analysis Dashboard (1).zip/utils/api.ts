import { projectId, publicAnonKey } from './supabase/info'
import { exportData as clientExportData, validateExportData, ExportData } from './clientExport'

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-bd15aa81`

export interface SentimentAnalysis {
  id: string
  userId: string
  timestamp: string
  text?: string
  results?: Array<{
    text: string
    sentiment: string
    confidence: number
    scores: {
      positive: number
      negative: number
      neutral: number
    }
    keywords?: string[]
  }>
  batchResults?: Array<{
    text: string
    sentiment: string
    confidence: number
    scores: {
      positive: number
      negative: number
      neutral: number
    }
  }>
  summary?: {
    totalAnalyzed: number
    averageConfidence: number
    sentimentDistribution: {
      positive: number
      negative: number
      neutral: number
    }
  }
}

export type ExportFormat = 'json' | 'csv' | 'pdf'

export interface ExportOptions {
  format: ExportFormat
  includeCharts?: boolean
  filename?: string
}

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message)
    this.name = 'ApiError'
  }
}

async function apiRequest<T>(
  endpoint: string, 
  options: RequestInit = {},
  accessToken?: string
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${accessToken || publicAnonKey}`,
    ...options.headers,
  }

  try {
    const response = await fetch(url, {
      ...options,
      headers,
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new ApiError(
        response.status, 
        errorData.error || `HTTP ${response.status}: ${response.statusText}`
      )
    }

    return await response.json()
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    
    console.error(`API request failed for ${endpoint}:`, error)
    throw new Error(`Network error while calling ${endpoint}: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}

export const api = {
  // Auth
  async signup(email: string, password: string, name?: string) {
    return apiRequest<{ user: any }>('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    })
  },

  // Analysis
  async saveAnalysis(analysis: Partial<SentimentAnalysis>, accessToken?: string) {
    return apiRequest<{ success: boolean; analysisId: string; message: string }>(
      '/analysis/save',
      {
        method: 'POST',
        body: JSON.stringify(analysis),
      },
      accessToken
    )
  },

  async getAnalysisHistory(accessToken?: string) {
    return apiRequest<{ analyses: SentimentAnalysis[] }>(
      '/analysis/history',
      { method: 'GET' },
      accessToken
    )
  },

  async getAnalysis(id: string, accessToken?: string) {
    return apiRequest<{ analysis: SentimentAnalysis }>(
      `/analysis/${id}`,
      { method: 'GET' },
      accessToken
    )
  },

  async deleteAnalysis(id: string, accessToken?: string) {
    return apiRequest<{ success: boolean; message: string }>(
      `/analysis/${id}`,
      { method: 'DELETE' },
      accessToken
    )
  },

  // Enhanced export functions with fallback
  async exportAnalysis(analysisId: string, options: ExportOptions) {
    try {
      return await apiRequest<{ success: boolean; downloadUrl: string; fileName: string; format: string }>(
        '/analysis/export',
        {
          method: 'POST',
          body: JSON.stringify({ 
            analysisId, 
            format: options.format,
            includeCharts: options.includeCharts || false
          }),
        }
      )
    } catch (error) {
      console.warn('Backend export failed, attempting fallback:', error)
      throw error // Let the calling component handle fallback
    }
  },

  async exportData(data: any, options: ExportOptions) {
    try {
      return await apiRequest<{ success: boolean; downloadUrl: string; fileName: string; format: string }>(
        '/export/direct',
        {
          method: 'POST',
          body: JSON.stringify({ 
            data, 
            format: options.format,
            filename: options.filename,
            includeCharts: options.includeCharts || false
          }),
        }
      )
    } catch (error) {
      console.warn('Backend export failed, attempting fallback:', error)
      throw error // Let the calling component handle fallback
    }
  },

  // Client-side export fallback
  async exportDataClientSide(data: any, options: ExportOptions): Promise<{ success: boolean; message: string; format: string }> {
    try {
      if (!validateExportData(data)) {
        throw new Error('Invalid export data: No results found')
      }

      const filename = options.filename || 'sentiment-analysis'
      await clientExportData(data as ExportData, options.format, filename)
      
      return {
        success: true,
        message: options.format === 'pdf' 
          ? 'Exported as JSON (PDF requires backend processing)'
          : `Successfully exported as ${options.format.toUpperCase()}`,
        format: options.format === 'pdf' ? 'json' : options.format
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Client-side export failed'
      throw new Error(errorMessage)
    }
  },

  // Health check
  async health() {
    return apiRequest<{ status: string; timestamp: string }>('/health')
  }
}