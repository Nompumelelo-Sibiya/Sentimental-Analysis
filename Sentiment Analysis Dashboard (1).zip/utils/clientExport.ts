export type ExportFormat = 'json' | 'csv' | 'pdf'

export interface ExportData {
  results?: Array<{
    text: string
    sentiment: string
    confidence: number
    scores: {
      positive: number
      negative: number
      neutral: number
    }
    keywords?: string[]
  }>
  batchResults?: Array<{
    text: string
    sentiment: string
    confidence: number
    scores: {
      positive: number
      negative: number
      neutral: number
    }
  }>
  text?: string
  summary?: {
    totalAnalyzed: number
    averageConfidence: number
    sentimentDistribution: {
      positive: number
      negative: number
      neutral: number
    }
  }
}

export function generateCSV(data: ExportData): string {
  const results = data.results || data.batchResults || []
  
  if (results.length === 0) {
    return 'No data to export'
  }

  const headers = ['Text', 'Sentiment', 'Confidence', 'Positive', 'Negative', 'Neutral', 'Keywords']
  const rows = [headers.join(',')]
  
  results.forEach((result) => {
    const row = [
      `"${result.text.replace(/"/g, '""')}"`,
      result.sentiment,
      result.confidence.toFixed(3),
      result.scores.positive.toFixed(3),
      result.scores.negative.toFixed(3),
      result.scores.neutral.toFixed(3),
      `"${(result.keywords || []).join(', ')}"`
    ]
    rows.push(row.join(','))
  })
  
  // Add summary if available
  if (data.summary) {
    rows.push('')
    rows.push('SUMMARY')
    rows.push(`Total Analyzed,${data.summary.totalAnalyzed}`)
    rows.push(`Average Confidence,${data.summary.averageConfidence.toFixed(3)}`)
    rows.push(`Positive Count,${data.summary.sentimentDistribution.positive}`)
    rows.push(`Negative Count,${data.summary.sentimentDistribution.negative}`)
    rows.push(`Neutral Count,${data.summary.sentimentDistribution.neutral}`)
  }
  
  return rows.join('\n')
}

export function generateJSON(data: ExportData): string {
  return JSON.stringify({
    exportedAt: new Date().toISOString(),
    ...data
  }, null, 2)
}

export function generatePDFAsJSON(data: ExportData): string {
  return JSON.stringify({
    note: 'PDF export requires backend processing. This file contains the raw data in JSON format.',
    recommendation: 'Use a backend service or PDF generation library to create proper PDF reports.',
    exportedAt: new Date().toISOString(),
    data: data
  }, null, 2)
}

export function downloadFile(content: string, filename: string, contentType: string): void {
  const blob = new Blob([content], { type: contentType })
  const url = window.URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  link.style.display = 'none'
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  window.URL.revokeObjectURL(url)
}

export function exportData(
  data: ExportData, 
  format: ExportFormat, 
  filename: string
): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
      const finalFilename = `${filename}-${timestamp}`
      
      let content: string
      let contentType: string
      let fileExtension: string

      switch (format) {
        case 'json':
          content = generateJSON(data)
          contentType = 'application/json'
          fileExtension = '.json'
          break
        case 'csv':
          content = generateCSV(data)
          contentType = 'text/csv'
          fileExtension = '.csv'
          break
        case 'pdf':
          // Fallback to JSON for PDF
          content = generatePDFAsJSON(data)
          contentType = 'application/json'
          fileExtension = '.json'
          break
        default:
          throw new Error(`Unsupported format: ${format}`)
      }

      downloadFile(content, finalFilename + fileExtension, contentType)
      resolve()
    } catch (error) {
      reject(error)
    }
  })
}

// Validate export data
export function validateExportData(data: any): boolean {
  if (!data) return false
  
  const hasResults = (data.results && Array.isArray(data.results) && data.results.length > 0)
  const hasBatchResults = (data.batchResults && Array.isArray(data.batchResults) && data.batchResults.length > 0)
  const isArrayOfResults = Array.isArray(data) && data.length > 0
  
  return hasResults || hasBatchResults || isArrayOfResults
}